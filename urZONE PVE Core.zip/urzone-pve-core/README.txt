# urZONE PVE Core 2.7.0

**What's new in 2.7.0**
- PegaProx-inspired dark layered UI (deeper surfaces, refined cards, polished floating windows/popups).
- Assets extracted to `assets/css/` and `assets/js/` for easier maintenance.
- All original functions, shortcode behaviour, floating cards, popups, live updates and terminal integration kept intact.
- Formal WordPress / PHP version requirements declared.

See CHANGELOG.md for details.

---

# urZONE PVE — Installation Guide

This guide walks through setting up urZONE PVE from nothing: creating the Proxmox API token, installing the plugin, configuring `wp-config.php`, and testing it end to end. Follow the steps in order — most problems come from skipping one.

**Time needed:** 15–20 minutes for the core plugin. The optional in-browser Shell adds another 10–15 minutes and needs your WordPress site and Proxmox host to share a domain (details in Part 5).

---

## What you need before starting

- A WordPress site, with admin (or Super Admin, on multisite) access
- A Proxmox VE host, reachable over the network from your WordPress server, with admin access to its web interface
- The ability to edit `wp-config.php` on your WordPress server (via SFTP, hosting file manager, or SSH)

---

## Part 1 — Create the Proxmox API token

1. Log in to the Proxmox web interface.
2. Go to **Datacenter → Permissions → API Tokens**.
3. Click **Add**.
4. Set **User** to `root@pam`.
5. Set **Token ID** to something memorable, e.g. `urzone`.
6. **Uncheck "Privilege Separation."** This is the single most common setup mistake — see the box below.
7. Click **Add**, then **copy the Secret shown on screen immediately.** Proxmox only shows it once; if you close the dialog without copying it, you'll need to delete the token and create a new one.

> **Why uncheck Privilege Separation?**
> With it checked, the token only has the rights you explicitly grant *to the token itself*, separately from `root@pam`'s own rights — and the plugin needs broad access (create, start, stop, and delete guests; read storage contents; and, if you enable the Shell feature, create Proxmox users and grant permissions). Leaving Privilege Separation on is what produces the error **"Permission check failed"** later.

You should now have three values: the user (`root@pam`), the Token ID (`urzone`), and the Secret (a long string shown only once).

---

## Part 2 — Install the plugin files

1. Upload `urzone-pve.php` to `wp-content/plugins/` on your WordPress site (either as a loose file, or inside its own folder — both work).
2. In **Plugins**, find **urZONE PVE** and click **Activate**.

Don't add the shortcode to a page yet — it won't work until Part 3 is done, and that's expected.

---

## Part 3 — Configure wp-config.php

Open `wp-config.php` and add the lines below **above** the line that says:
```php
/* That's all, stop editing! Happy publishing. */
```

### Required

```php
define( 'URZONE_PROXMOX_API_URL', 'https://YOUR_PVE_IP:8006/api2/json' );
define( 'URZONE_PROXMOX_API_USER', 'root@pam' );
define( 'URZONE_PROXMOX_API_TOKEN_ID', 'urzone' );
define( 'URZONE_PROXMOX_API_TOKEN_SECRET', 'PASTE_YOUR_SECRET_HERE' );
```

| Constant | What goes here |
|---|---|
| `URZONE_PROXMOX_API_URL` | Your Proxmox host's address, **including `/api2/json` at the end**, and the port (usually `8006`) unless you're going through a reverse proxy that already sends plain HTTPS to it. Use the address your *WordPress server* can reach — not necessarily the same one you use in your own browser. |
| `URZONE_PROXMOX_API_USER` | The user half of the token, exactly as it appears in Proxmox (usually `root@pam`). No `!token` suffix here. |
| `URZONE_PROXMOX_API_TOKEN_ID` | Just the Token ID you chose (e.g. `urzone`) — not the user, and not the full `root@pam!urzone` form. |
| `URZONE_PROXMOX_API_TOKEN_SECRET` | The Secret Proxmox showed you once in Part 1. |

> **Three mistakes that will break this silently:** a missing `);` at the end of a line, a stray character instead of `);` (easy to introduce when copy-pasting from somewhere that auto-"corrects" quotes), and forgetting to remove the leading `//` if you're uncommenting an existing line. Any one of these can take down the *entire site*, not just this plugin, so re-check the lines you just added before moving on.

### Optional, with their defaults

None of these are required to get started — the plugin works with the four lines above alone.

```php
define( 'URZONE_PROXMOX_SSLVERIFY', false );
define( 'URZONE_PROXMOX_DEFAULT_NODE', 'pve' );
define( 'URZONE_PROXMOX_DEFAULT_STORAGE', 'local-lvm' );
define( 'URZONE_PROXMOX_DEFAULT_BRIDGE', 'vmbr0' );
define( 'URZONE_PROXMOX_TEMPLATE_STORAGE', 'local' );
define( 'URZONE_PROXMOX_ISO_STORAGE', 'local' );
define( 'URZONE_PROXMOX_MAX_INSTANCES', 5 );
define( 'URZONE_PROXMOX_POLL_SECONDS', 5 );
define( 'URZONE_PROXMOX_MAX_CORES', 4 );
define( 'URZONE_PROXMOX_MAX_MEMORY', 8192 );
define( 'URZONE_PROXMOX_MAX_DISK_GB', 100 );
```

| Constant | Default | What it controls |
|---|---|---|
| `URZONE_PROXMOX_SSLVERIFY` | `false` | Whether to verify Proxmox's SSL certificate. Leave `false` unless Proxmox has a certificate your server actually trusts (Proxmox's default self-signed one won't be). |
| `URZONE_PROXMOX_DEFAULT_NODE` | `pve` | The Proxmox node name non-admin users create instances on. Must match a real node name in your cluster exactly. |
| `URZONE_PROXMOX_DEFAULT_STORAGE` | `local-lvm` | Where new disks are created. Must be a storage ID that exists on that node and supports disk images. |
| `URZONE_PROXMOX_DEFAULT_BRIDGE` | `vmbr0` | The network bridge new guests are attached to. |
| `URZONE_PROXMOX_TEMPLATE_STORAGE` | `local` | Where LXC templates (`.tar.zst`/`.tar.gz` files) are looked up. |
| `URZONE_PROXMOX_ISO_STORAGE` | `local` | Where ISO images are looked up. |
| `URZONE_PROXMOX_MAX_INSTANCES` | `5` | How many containers/VMs a non-admin user may hold at once. `-1` = unlimited, `0` = none. |
| `URZONE_PROXMOX_POLL_SECONDS` | `5` | How often the dashboard refreshes live stats, in seconds (minimum enforced: 3). |
| `URZONE_PROXMOX_MAX_CORES` | `4` | Per-instance CPU core cap for non-admins. `0` = no extra cap. |
| `URZONE_PROXMOX_MAX_MEMORY` | `8192` | Per-instance memory cap in MB for non-admins. `0` = no extra cap. |
| `URZONE_PROXMOX_MAX_DISK_GB` | `100` | Per-instance disk size cap in GB for non-admins. `0` = no extra cap. |

Super admins (or site admins, on a single-site install) are exempt from every limit above.

---

## Part 4 — Confirm storage, node, and template names match reality

The defaults above (`pve`, `local-lvm`, `vmbr0`, `local`) are common, but **not guaranteed to match your setup.** Before testing, check in Proxmox:

1. **Datacenter → your node** — confirm the node's actual name (shown in the left-hand tree) matches `URZONE_PROXMOX_DEFAULT_NODE`.
2. **your node → your-storage → Summary** — confirm a storage with that name exists and shows "Images"/"Disk image" under its content types, for `URZONE_PROXMOX_DEFAULT_STORAGE`.
3. Same check for `URZONE_PROXMOX_TEMPLATE_STORAGE` (needs "Container template" content) and `URZONE_PROXMOX_ISO_STORAGE` (needs "ISO image" content).
4. **your node → System → Network** — confirm the bridge name for `URZONE_PROXMOX_DEFAULT_BRIDGE`.

If any of these don't match, either rename the constant in `wp-config.php` to the real value, or (for storage) add the right content type to an existing storage in Proxmox under **Storage → Edit**.

---

## Part 5 — Add the shortcode and test it

1. Create or edit a page, and add the shortcode:
   ```
   [urzone_pve]
   ```
   (`[urzone-pve]` with a hyphen also works, in case your editor won't let you type an underscore cleanly.)
2. Visit that page **while logged in** — logged-out visitors are shown a message asking them to log in, by design.
3. You should see the dashboard load with **"Live · every 5s"** and no red error banner. If you see your containers/VMs (or an empty list, if you don't own any yet), the connection works.

If you see an error instead, skip to **Troubleshooting** below before going further — don't try the Shell setup in Part 6 until the base connection works.

### Try creating something

4. Open **Create New Instance**, pick the **LXC Container** tab, fill in a hostname, pick a template, and set a root password (8+ characters).
5. Submit. You should see a success message and, after a few seconds, a new card appear.
6. Try **Start**, **Stop**, and (once stopped) **Delete** on it to confirm actions work.

---

## Part 6 — Optional: the in-browser Shell

The Shell button opens a real Proxmox console for a customer's own container or VM, directly in the page — no separate Proxmox login needed. **This is the most environment-dependent part of the plugin and can be skipped entirely** — without it configured, the Shell button simply stays disabled, and everything else works normally.

### How it works, briefly

Proxmox's console needs a real login session, which an API token can't provide. So when a user clicks Shell, the plugin automatically creates a low-privilege Proxmox account for them (`uzwp<their WordPress user ID>@pve`), grants it console access to *only* that one guest, and signs the browser in for just long enough to show the console.

### What this requires

1. **The token needs permission to manage users, roles, and permissions** — which you already have if you followed Part 1 (`root@pam` with Privilege Separation off covers this; no extra step needed).
2. **Your Proxmox host must be reachable at an address that shares a parent domain with your WordPress site.** This is a hard requirement — Proxmox's login cookie can only be set for a domain the browser considers related to the current page. For example, if WordPress is at `example.com`, Proxmox needs to be reachable at something like `pve.example.com` — not at a bare IP address, and not at a completely unrelated domain.
3. Set this in `wp-config.php`:
   ```php
   define( 'URZONE_PROXMOX_CONSOLE_URL', 'https://pve.example.com' );
   ```
   If you leave this undefined, the plugin tries to derive it from `URZONE_PROXMOX_API_URL` automatically — which only works if that URL is already a proper hostname (not a bare IP) sharing a domain with your site.
4. **Proxmox must not refuse to be shown inside a frame.** If your Proxmox host sits behind a reverse proxy (Nginx, Nginx Proxy Manager, Cloudflare, etc.), that proxy must not send an `X-Frame-Options` header that blocks framing, and any `Content-Security-Policy` header must include your site's domain under `frame-ancestors`. This is a setting on *your proxy*, not something the plugin controls.

### Testing it

5. Click Shell on a *running* container or VM you own.
6. If it works, a window opens on the page with a resize control (`-`/`+`) and a close button (`×`), showing the real Proxmox console.
7. If it shows an error or stays blank, see Troubleshooting below — the error message on screen usually names the specific problem.

---

## Troubleshooting

| What you see | What it means | What to do |
|---|---|---|
| **"Proxmox returned HTTP 401"** | The token, user, or secret doesn't match what Proxmox has. | Re-check all three values in `wp-config.php` character-for-character against Datacenter → Permissions → API Tokens. |
| **"Permission check failed"** | The token can't do what was asked. | Almost always means Privilege Separation is still on for the token — go back and uncheck it. |
| **"Proxmox returned HTTP 301" / a redirect loop** | The API URL is slightly wrong — usually a missing/extra port, or `http://` instead of `https://`. | Test the address directly: `curl -k -s -D - -o /dev/null https://YOUR_URL/version` from the WordPress server itself, and adjust the URL based on what it shows. |
| **cURL error 7 ("connection refused")** | Nothing is listening at that address/port from the WordPress server's point of view. | Confirm the port and that nothing (a firewall, a proxy) is blocking it between the two servers. |
| **cURL error 28 ("timed out")** | The address is reachable but not answering — often because Proxmox itself is under heavy disk load (high I/O delay) at that moment, or a firewall is silently dropping the connection instead of rejecting it. | Wait a few seconds and retry; if it persists, check Proxmox's own load and connectivity. |
| **A 502 error on the whole page after editing wp-config.php** | A typo in the lines you added caused a fatal PHP error, or every request is now timing out waiting on an unreachable Proxmox. | Re-check the exact syntax of each `define()` line; temporarily deactivate the plugin to confirm the site itself is fine. |
| **A container/VM shows no IP address** | For LXC, this should resolve within a few seconds on its own. For VMs, the IP can only be detected via the QEMU Guest Agent running inside the guest — which has to already be installed in the OS image or template you used. | See the UVCPanel guide's FAQ for the full explanation; this is a guest-OS requirement, not something fixable from the plugin. |
| **Shell shows "refused to connect" or stays blank** | Usually means Proxmox is refusing to be framed, or `URZONE_PROXMOX_CONSOLE_URL` points somewhere that doesn't share a domain with your site. | Check your reverse proxy's framing headers, and confirm the console URL is a real hostname on the same parent domain as your WordPress site. |
| **Shell shows "No ticket (401)"** | The browser isn't holding a valid Proxmox login cookie — usually a leftover from a previous session. | Close any open Shell windows (which clears the cookie) and try again. |

---

## For multisite installs

On a WordPress multisite network, only **network Super Admins** count as unrestricted administrators in this plugin — a site's regular Administrator is treated as a normal, limited user, subject to the instance and resource caps above. This is intentional: on a multisite network, every customer typically has Administrator rights on their own site.

---

## Tying limits to a membership plan

The instance limit can be overridden per user two ways, without editing the plugin:

- **Per user, by hand:** in **Users → Edit User**, a site admin will see a **"Max instances"** field. Leave it blank for the site default, or set a number (`-1` for unlimited, `0` to block creation entirely).
- **Programmatically, for a membership/plans system:** hook the `urzone_pve_max_instances` filter, e.g. in a small must-use plugin:
  ```php
  add_filter( 'urzone_pve_max_instances', function ( $limit, $user_id ) {
      // Return a different number based on the user's plan.
      return $limit;
  }, 10, 2 );
  ```
  This is a hook only — the plugin does not ship with any specific plan/tier system built in.