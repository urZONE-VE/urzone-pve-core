urZONE PVE — Copyright, Ownership, and Intellectual Property Notice

Copyright © 2026 Richard Charles Simmons, also known as Osiris Simmons
and Osiris83. All rights reserved.

urZONE PVE, including its original software source code, custom WordPress
integration logic, provisioning and orchestration workflows, administrative
interfaces, client dashboard features, terminal-console integration workflows,
configuration structures, documentation, written materials, visual presentation,
trade dress, logos, names, and branding elements, is an original work created
and owned by Richard Charles Simmons (“Owner” or “Author”), except where
third-party materials are specifically identified.

The names “Richard Charles Simmons,” “Osiris Simmons,” and “Osiris83” identify
the Author and copyright claimant for urZONE PVE. Any use of those names in
connection with urZONE PVE is an attribution of authorship and ownership.

No person or organization may copy, reproduce, modify, distribute, sell, lease,
rent, sublicense, publish, publicly display, reverse engineer, decompile,
disassemble, remove attribution from, or create derivative works based upon the
proprietary original portions of urZONE PVE without the prior written permission
of Richard Charles Simmons.

This notice is not a transfer, waiver, abandonment, dedication to the public
domain, or grant of any license. All rights not expressly granted in a written
license are reserved by Richard Charles Simmons.

Nothing in this notice claims ownership of WordPress, Proxmox VE, xterm.js,
Linux distributions, third-party libraries, open-source components, trademarks,
or other materials owned by their respective rights holders. Such components
remain subject to their respective licenses, copyrights, trademarks, and terms.

The Owner claims copyright only in the original elements of urZONE PVE and does
not claim exclusive rights in pre-existing, third-party, open-source, functional,
standard, or publicly available materials incorporated into, used with, or
interoperable with the software.

For licensing, permissions, copyright inquiries, or reports of unauthorized use,
contact:
Richard Charles Simmons / Osiris Simmons / Osiris83
[Insert your business email, website, or legal-contact address]