# Changelog — urZONE PVE Core

## 2.8.0 — 2026-10-21

### New
- Free edition: the "urZONE Core Plans" admin page (where you set panels per plan) is not included. Plans use the built-in limits.

### Changed
- `urzone_pve_plans()` uses the built-in limits (1 / 5 / 10 / 20). The `urzone_pve_plan_limit` filter still has the final say.

## 2.7.1 — 2026-10-21

### Critical fixes
- Restored full original CSS structure (grid/layer mode, list view, jobs, demo banner, cards, buttons, charts).
- Fixed grid vs layer mode: grid hides list, layer hides grid cards (as designed).
- Fixed floating windows: `position: fixed` restored so drag / move works again.
- Fixed layer overlay z-index and pointer-events so windows are interactive.

### New
- Dark / Light mode toggle (button in header, preference saved in localStorage).

### Notes
- All original PHP functions and JS behaviour retained.
- Assets still in `assets/css/` and `assets/js/`.

## 2.7.0 — 2026-10-20
- Initial asset extraction and theme experiment (superseded by 2.7.1 for correctness).

## 2.6.1 — previous
- Core engine: Proxmox API, plans, ownership, demo mode, REST routes, renderer.
