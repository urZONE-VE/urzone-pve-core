(function () {
		const W = 300, H = 64, N = 60;
		const COLORS = { cpu: '#4fdc90', mem: '#5aaeff', rx: '#b486ff', tx: '#ffb15a', rd: '#54d6db', wr: '#ff7f9f', io: '#ff6f6f' };
		const SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
		const ICON_MAX = SVG + '<rect x="4" y="4" width="16" height="16" rx="1.5"/></svg>';
		const ICON_RESTORE = SVG + '<rect x="4" y="8" width="12" height="12" rx="1.5"/><path d="M8 8V5.5A1.5 1.5 0 0 1 9.5 4H18.5A1.5 1.5 0 0 1 20 5.5V14.5A1.5 1.5 0 0 1 18.5 16H16"/></svg>';
		const ICON_CLOSE = SVG + '<path d="M5 5l14 14M19 5L5 19"/></svg>';

		const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
		const fmtPct = v => v.toFixed(1) + '%';
		const fmtRate = function (v) {
			const u = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
			let i = 0;
			while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
			return v.toFixed(i ? 1 : 0) + ' ' + u[i];
		};
		const fmtBytes = function (v) {
			if (!v) return '—';
			const u = ['B', 'KB', 'MB', 'GB', 'TB'];
			let i = 0;
			while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
			return v.toFixed(i ? 1 : 0) + ' ' + u[i];
		};
		const fmtUp = function (s) {
			if (!s) return '—';
			const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
			return d ? d + 'd ' + h + 'h' : h ? h + 'h ' + m + 'm' : m + 'm';
		};
		const push = (a, v) => { a.push(v); if (a.length > N) a.shift(); };
		const last = a => a.length ? a[a.length - 1] : 0;
		const peak = a => a.reduce((m, v) => v > m ? v : m, 0);

		/* Inline-SVG line chart; first series also gets a soft area fill. */
		function draw(svg, series, fixedMax, n) {
			let max = fixedMax || 0;
			if (!fixedMax) series.forEach(s => s.data.forEach(v => { if (v > max) max = v; }));
			if (max <= 0) max = 1;
			const pad = 3;
			let html = '<line x1="0" y1="' + (H - 1) + '" x2="' + W + '" y2="' + (H - 1) + '" stroke="#2b4058" stroke-width="1" vector-effect="non-scaling-stroke"/>' +
				'<line x1="0" y1="' + (H / 2) + '" x2="' + W + '" y2="' + (H / 2) + '" stroke="#1d2e40" stroke-width="1" stroke-dasharray="3 4" vector-effect="non-scaling-stroke"/>';

			series.forEach(function (s, si) {
				const d = s.data;
				if (d.length < 2) return;
				let p = '', firstX = 0, lastX = 0;
				d.forEach(function (v, j) {
					const x = W - ((d.length - 1 - j) / (n - 1)) * W;
					const y = H - pad - Math.min(v / max, 1) * (H - pad * 2);
					if (j === 0) firstX = x;
					lastX = x;
					p += (j ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1) + ' ';
				});
				if (si === 0) html += '<path d="' + p + 'L' + lastX.toFixed(1) + ' ' + H + ' L' + firstX.toFixed(1) + ' ' + H + ' Z" fill="' + s.color + '" opacity=".14"/>';
				html += '<path d="' + p + '" fill="none" stroke="' + s.color + '" stroke-width="2" vector-effect="non-scaling-stroke"/>';
			});

			svg.innerHTML = html;
		}

		function setTile(scope, key, series, fixedMax, text, n) {
			const tile = scope.querySelector('[data-tile="' + key + '"]');
			if (!tile) return;
			tile.querySelector('[data-val]').textContent = text;
			draw(tile.querySelector('svg'), series, fixedMax, n);
		}

		function init(root) {
			const cfg = root.dataset;
			const state = {};
			const liveEl = root.querySelector('[data-live]');
			let timer = null, fails = 0;

			/* ---------- floating-window layer (lives on <body>, so it can cover the whole page) ---------- */
			const layer = document.createElement('div');
			layer.className = 'urzone-pve uzp-layer';
			document.body.appendChild(layer);

			const wins = {};
			let zTop = 1, cascade = 0;

			function makeWindow(o) {
				const el = document.createElement('div');
				el.className = 'uzp-win' + (o.resizable === false ? ' no-resize' : '');
				el.setAttribute('role', 'dialog');

				const bar = document.createElement('div');
				bar.className = 'uzp-win-bar';

				const title = document.createElement('span');
				title.className = 'uzp-win-title';
				title.textContent = o.title || '';

				const stateEl = document.createElement('span');
				stateEl.className = 'uzp-win-state';

				const btns = document.createElement('span');
				btns.className = 'uzp-win-btns';

				let maxBtn = null;
				if (o.maximizable !== false) {
					maxBtn = document.createElement('button');
					maxBtn.type = 'button';
					maxBtn.className = 'uzp-win-btn';
					maxBtn.title = 'Maximize';
					maxBtn.setAttribute('aria-label', 'Maximize');
					maxBtn.innerHTML = ICON_MAX;
					btns.appendChild(maxBtn);
				}

				const closeBtn = document.createElement('button');
				closeBtn.type = 'button';
				closeBtn.className = 'uzp-win-btn uzp-win-x';
				closeBtn.title = 'Close';
				closeBtn.setAttribute('aria-label', 'Close');
				closeBtn.innerHTML = ICON_CLOSE;
				btns.appendChild(closeBtn);

				bar.appendChild(title);
				bar.appendChild(stateEl);
				bar.appendChild(btns);

				const body = document.createElement('div');
				body.className = 'uzp-win-body' + (o.noscroll ? ' is-term' : '');
				if (o.body) body.appendChild(o.body);

				el.appendChild(bar);
				el.appendChild(body);

				let overlay = null;
				if (o.modal) {
					overlay = document.createElement('div');
					overlay.className = 'uzp-overlay';
					overlay.style.zIndex = ++zTop;
					layer.appendChild(overlay);
				}

				const vw = window.innerWidth, vh = window.innerHeight;
				const w = Math.min(o.width || 560, vw - 16);
				el.style.width = w + 'px';
				if (o.height) el.style.height = Math.min(o.height, vh - 16) + 'px';

				if (o.modal) {
					el.style.left = Math.max(8, Math.round((vw - w) / 2)) + 'px';
					el.style.top = Math.max(8, Math.round(vh * 0.22)) + 'px';
				} else {
					const off = (cascade++ % 8) * 28;
					el.style.left = Math.max(8, Math.round((vw - w) / 2) - 100 + off) + 'px';
					el.style.top = Math.max(8, 70 + off) + 'px';
				}

				const front = () => { el.style.zIndex = ++zTop; };
				front();
				el.addEventListener('pointerdown', front, true);

				/* drag by the title bar */
				let drag = null;
				bar.addEventListener('pointerdown', function (e) {
					if (e.target.closest('button') || el.classList.contains('is-max') || e.button > 0) return;
					const r = el.getBoundingClientRect();
					drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
					try { bar.setPointerCapture(e.pointerId); } catch (err) {}
					e.preventDefault();
				});
				bar.addEventListener('pointermove', function (e) {
					if (!drag) return;
					const r = el.getBoundingClientRect();
					const x = Math.min(Math.max(e.clientX - drag.dx, 80 - r.width), window.innerWidth - 80);
					const y = Math.min(Math.max(e.clientY - drag.dy, 0), window.innerHeight - 40);
					el.style.left = x + 'px';
					el.style.top = y + 'px';
				});
				const endDrag = () => { drag = null; };
				bar.addEventListener('pointerup', endDrag);
				bar.addEventListener('pointercancel', endDrag);

				/* maximize / restore */
				function toggleMax() {
					if (!maxBtn) return;
					const on = el.classList.toggle('is-max');
					maxBtn.innerHTML = on ? ICON_RESTORE : ICON_MAX;
					maxBtn.title = on ? 'Restore' : 'Maximize';
					maxBtn.setAttribute('aria-label', on ? 'Restore' : 'Maximize');
				}
				if (maxBtn) {
					maxBtn.addEventListener('click', toggleMax);
					bar.addEventListener('dblclick', function (e) { if (!e.target.closest('button')) toggleMax(); });
				}

				let closed = false;
				function close() {
					if (closed) return;
					closed = true;
					if (overlay) overlay.remove();
					el.remove();
					if (o.key) delete wins[o.key];
					if (o.onClose) o.onClose();
				}
				closeBtn.addEventListener('click', close);

				layer.appendChild(el);

				const api = { el: el, body: body, front: front, close: close, setState: t => { stateEl.textContent = t; } };
				if (o.key) wins[o.key] = api;
				return api;
			}

			/* ---------- live status ---------- */
			const cardsOf = vmid => [root, layer].reduce((a, c) => a.concat(Array.from(c.querySelectorAll('[data-card="' + vmid + '"]'))), []);

			function live(ok, msg) {
				if (!liveEl) return;
				liveEl.className = 'uzp-live ' + (ok ? 'on' : 'off');
				liveEl.textContent = ok ? 'Live · every ' + cfg.interval + 's' : 'Paused: ' + (msg || 'connection problem');
			}

			function setStatus(card, status) {
				card.dataset.status = status;
				card.querySelector('[data-badge]').textContent = status;
				const running = status === 'running';
				card.querySelectorAll('[data-need]').forEach(function (b) {
					b.disabled = b.dataset.need === 'running' ? !running : running;
				});
			}

			const pendingIds = (cfg.pending || '').split(',').filter(Boolean); // still being created: shown as a progress bar

			function apply(j) {
				let running = 0;
				const guests = j.guests.filter(g => !pendingIds.includes(String(g.vmid)));

				// A guest was created or removed: reload so cards and rows match (at most once every 20 seconds).
				const shown = Array.from(root.querySelectorAll('.uzp-vms [data-card]')).map(c => c.dataset.card).sort().join(',');
				const incoming = guests.map(g => String(g.vmid)).sort().join(',');
				if (shown !== incoming) {
					let lastReload = 0;
					try { lastReload = Number(sessionStorage.getItem('uzpve_reload') || 0); } catch (e) {}
					if (Date.now() - lastReload > 20000) {
						try { sessionStorage.setItem('uzpve_reload', String(Date.now())); } catch (e) {}
						window.location.reload();
						return;
					}
				}

				guests.forEach(function (g) {
					const on = g.status === 'running';
					if (on) running++;

					const s = state[g.vmid] || (state[g.vmid] = { cpu: [], mem: [], rx: [], tx: [], rd: [], wr: [], io: [], prev: null });
					let rx = 0, tx = 0, rd = 0, wr = 0;

					if (on && s.prev && j.ts > s.prev.ts) {
						const dt = j.ts - s.prev.ts;
						rx = Math.max(0, (g.netin - s.prev.netin) / dt);
						tx = Math.max(0, (g.netout - s.prev.netout) / dt);
						rd = Math.max(0, (g.diskread - s.prev.diskread) / dt);
						wr = Math.max(0, (g.diskwrite - s.prev.diskwrite) / dt);
					}

					s.prev = on ? { ts: j.ts, netin: g.netin, netout: g.netout, diskread: g.diskread, diskwrite: g.diskwrite } : null;

					push(s.cpu, on ? g.cpu * 100 : 0);
					push(s.mem, on && g.maxmem > 0 ? g.mem / g.maxmem * 100 : 0);
					push(s.rx, rx); push(s.tx, tx); push(s.rd, rd); push(s.wr, wr);
					push(s.io, (j.host.iowait || 0) * 100);

					const ramText = fmtBytes(g.mem) + ' / ' + fmtBytes(g.maxmem);

					cardsOf(g.vmid).forEach(function (card) {
						setStatus(card, g.status);
						card.querySelector('[data-ip]').textContent = g.ip || '—';
						card.querySelector('[data-uptime]').textContent = on ? fmtUp(g.uptime) : '—';
						card.querySelector('[data-ram]').textContent = ramText;

						setTile(card, 'cpu', [{ color: COLORS.cpu, data: s.cpu }], 100, fmtPct(last(s.cpu)), N);
						setTile(card, 'mem', [{ color: COLORS.mem, data: s.mem }], 100, fmtPct(last(s.mem)), N);
						setTile(card, 'net', [{ color: COLORS.rx, data: s.rx }, { color: COLORS.tx, data: s.tx }], 0, '↓ ' + fmtRate(last(s.rx)) + '  ↑ ' + fmtRate(last(s.tx)), N);
						setTile(card, 'disk', [{ color: COLORS.rd, data: s.rd }, { color: COLORS.wr, data: s.wr }], 0, 'R ' + fmtRate(last(s.rd)) + '  W ' + fmtRate(last(s.wr)), N);
						setTile(card, 'io', [{ color: COLORS.io, data: s.io }], 0, last(s.io).toFixed(2) + '%', N);
					});

					const row = root.querySelector('[data-row="' + g.vmid + '"]');
					if (row) {
						row.dataset.status = g.status;
						row.querySelector('[data-r-badge]').textContent = g.status;
						row.querySelector('[data-r-ip]').textContent = g.ip || '—';
						row.querySelector('[data-r-cpu]').textContent = on ? fmtPct(g.cpu * 100) : '—';
						row.querySelector('[data-r-mem]').textContent = on && g.maxmem > 0 ? fmtPct(g.mem / g.maxmem * 100) : '—';
						row.querySelector('[data-r-up]').textContent = on ? fmtUp(g.uptime) : '—';
					}
				});

				const r = root.querySelector('[data-sum-running]');
				const st = root.querySelector('[data-sum-stopped]');
				if (r) r.textContent = running;
				if (st) st.textContent = guests.length - running;
			}

			function poll() {
				return (async () => {
				try {
					const res = await fetch(cfg.overview + '?node=' + encodeURIComponent(cfg.node) + '&scope=' + encodeURIComponent(cfg.scope || 'own'), {
						credentials: 'same-origin',
						headers: { 'X-WP-Nonce': cfg.nonce, 'Accept': 'application/json' }
					});
					const j = await res.json();
					if (!res.ok) throw new Error(j.message || 'HTTP ' + res.status);
					fails = 0;
					live(true);
					apply(j);
				} catch (e) {
					fails++;
					live(false, e.message);
				}
				schedule();
				})();
			}

			function schedule() {
				clearTimeout(timer);
				if (document.hidden) return;
				timer = setTimeout(poll, Math.min(Number(cfg.interval) * 1000 * Math.pow(2, fails), 60000));
			}

			document.addEventListener('visibilitychange', function () {
				clearTimeout(timer);
				if (!document.hidden) poll();
			});

			/* ---------- confirmation window ---------- */
			function ask(button) {
				return new Promise(function (resolve) {
					const need = button.dataset.typeConfirm || '';
					const danger = button.classList.contains('uzp-danger') || button.classList.contains('uzp-warn');

					const body = document.createElement('div');
					body.className = 'uzp-confirm';
					body.innerHTML =
						'<p class="uzp-confirm-msg" data-msg></p>' +
						'<label data-type-wrap hidden>Type <b data-expect></b> to confirm <input type="text" autocomplete="off"></label>' +
						'<div class="uzp-dialog-actions"><button type="button" class="uzp-btn" data-cancel>Cancel</button><button type="button" class="uzp-btn" data-ok>Confirm</button></div>';

					body.querySelector('[data-msg]').textContent = button.dataset.confirm;
					body.querySelector('[data-type-wrap]').hidden = !need;
					body.querySelector('[data-expect]').textContent = need;

					const input = body.querySelector('input');
					const ok = body.querySelector('[data-ok]');
					ok.disabled = !!need;
					ok.className = 'uzp-btn ' + (danger ? 'uzp-danger' : 'uzp-go');
					ok.style.marginLeft = '0';

					let done = false;
					const win = makeWindow({
						title: 'Please confirm', body: body, modal: true, maximizable: false, resizable: false, width: 440,
						onClose: function () { if (!done) { done = true; resolve(false); } }
					});
					const finish = function (v) { if (done) return; done = true; win.close(); resolve(v); };

					input.addEventListener('input', function () { ok.disabled = input.value.trim() !== need; });
					ok.addEventListener('click', function () { finish(true); });
					body.querySelector('[data-cancel]').addEventListener('click', function () { finish(false); });
					win.el.addEventListener('keydown', function (e) {
						if (e.key === 'Escape') finish(false);
						if (e.key === 'Enter' && e.target === input && !ok.disabled) { e.preventDefault(); finish(true); }
					});

					(need ? input : ok).focus();
				});
			}

			/* ---------- View: a container's card in its own floating window ---------- */
			function openCard(vmid) {
				const key = 'card:' + vmid;
				if (wins[key]) { wins[key].front(); return; }

				const src = root.querySelector('.uzp-vms [data-card="' + vmid + '"]');
				if (!src) return;

				const clone = src.cloneNode(true);
				clone.querySelectorAll('details[data-history]').forEach(function (d) {
					d.open = false;
					delete d.dataset.loaded;
					const g = d.querySelector('[data-hist]');
					if (g) g.innerHTML = '';
				});

				const nameEl = src.querySelector('.uzp-vm-name');
				makeWindow({ key: key, title: (nameEl ? nameEl.textContent : 'Instance') + ' · VMID ' + vmid, body: clone, width: 580 });
			}

			/* ---------- Shell window (xterm.js through the bridge) ---------- */
			async function openShell(btn) {
				const vmid = btn.dataset.vmid, key = 'shell:' + vmid;
				if (wins[key]) { wins[key].front(); return; }

				if (typeof Terminal === 'undefined' || typeof FitAddon === 'undefined') {
					alert('The shell library failed to load (check that cdn.jsdelivr.net is reachable).');
					return;
				}

				let term = null, fit = null, sock = null, ro = null;

				function teardown() {
					if (ro) { ro.disconnect(); ro = null; }
					if (sock) { sock.onclose = null; sock.onerror = null; try { sock.close(); } catch (e) {} sock = null; }
					if (term) { term.dispose(); term = null; }
					fit = null;
				}

				const box = document.createElement('div');
				box.className = 'uzp-term-box';

				const win = makeWindow({
					key: key, title: (btn.dataset.name || 'Container') + ' · Shell · VMID ' + vmid,
					body: box, width: 820, height: 520, noscroll: true, onClose: teardown
				});

				win.setState('Connecting…');

				term = new Terminal({ cursorBlink: true, fontSize: 14, fontFamily: 'ui-monospace, Menlo, Consolas, monospace', theme: { background: '#000000' } });
				fit = new FitAddon.FitAddon();
				term.loadAddon(fit);
				term.open(box);
				fit.fit();
				term.focus();

				let j;
				try {
					const res = await fetch(cfg.terminal + encodeURIComponent(btn.dataset.node) + '/' + encodeURIComponent(btn.dataset.type || 'lxc') + '/' + encodeURIComponent(vmid), {
						method: 'POST',
						credentials: 'same-origin',
						headers: { 'X-WP-Nonce': cfg.nonce, 'Accept': 'application/json' }
					});
					j = await res.json();
					if (!res.ok) throw new Error(j.message || 'HTTP ' + res.status);
				} catch (e) {
					win.setState('Error');
					if (term) term.writeln('\x1b[31m' + e.message + '\x1b[0m');
					return;
				}

				if (!term) return; // window was closed while connecting

				const ws = new WebSocket(j.url);
				ws.binaryType = 'arraybuffer';
				sock = ws;

				const sendSize = function () { if (ws.readyState === 1 && term) ws.send('r' + term.cols + ',' + term.rows); };

				ws.onopen = function () { win.setState('Connected'); sendSize(); };
				ws.onmessage = function (e) { if (term) term.write(typeof e.data === 'string' ? e.data : new Uint8Array(e.data)); };
				ws.onclose = function (e) { win.setState('Disconnected'); if (term) term.writeln('\r\n\x1b[33m[connection closed' + (e && e.reason ? ': ' + e.reason : '') + ']\x1b[0m'); };
				ws.onerror = function () { win.setState('Connection error'); };

				term.onData(function (d) { if (ws.readyState === 1) ws.send('d' + d); });
				term.onResize(sendSize);

				ro = new ResizeObserver(function () { if (fit) { try { fit.fit(); } catch (e) {} } });
				ro.observe(box);
			}

			/* ---------- Snapshot / Clone / Template (Layer view) ---------- */
			function openAction(btn) {
				const act = btn.dataset.act, vmid = btn.dataset.vmid, key = 'act:' + act + ':' + vmid;
				if (wins[key]) { wins[key].front(); return; }

				const isLxc = btn.dataset.type === 'lxc';
				const base = (btn.dataset.name || 'instance').replace(/[^A-Za-z0-9.-]/g, '-');
				const d = new Date(), z = n => String(n).padStart(2, '0');
				const stamp = d.getFullYear() + z(d.getMonth() + 1) + z(d.getDate()) + '-' + z(d.getHours()) + z(d.getMinutes());

				const defs = {
					snapshot: { title: 'Snapshot', action: 'snapshot', field: 'snap_name', label: 'Snapshot name', max: 40, pattern: '[A-Za-z][A-Za-z0-9_-]*', value: 'snap-' + stamp, go: 'Take snapshot',
						note: 'A snapshot saves the current state of this instance so it can be restored later. Names start with a letter and use only letters, numbers, - and _.' },
					clone: { title: 'Clone', action: 'clone_guest', field: 'copy_name', label: 'Name for the clone', max: 63, pattern: '[A-Za-z0-9][A-Za-z0-9.-]*', value: base.slice(0, 50) + '-clone', go: 'Create clone',
						note: 'Makes a full copy of this instance as a new one.' + (isLxc ? ' The container must be stopped first.' : '') },
					template: { title: 'Template', action: 'make_template', field: 'copy_name', label: 'Template name', max: 63, pattern: '[A-Za-z0-9][A-Za-z0-9.-]*', value: base.slice(0, 50) + '-template', go: 'Make template',
						note: 'Saves a copy of this virtual machine as a template you can create new VMs from. The original is not changed. Stop the VM first.' }
				};
				const c = defs[act];
				if (!c) return;

				const body = document.createElement('div');
				body.className = 'uzp-confirm';

				const form = document.createElement('form');
				form.method = 'post';

				const hid = function (n, v) {
					const i = document.createElement('input');
					i.type = 'hidden'; i.name = n; i.value = v;
					form.appendChild(i);
				};
				hid('urzone_pve_nonce', cfg.anonce);
				hid('urzone_pve_action', c.action);
				hid('node', cfg.node);
				hid('guest_type', btn.dataset.type);
				hid('vmid', vmid);
				hid('uzp_return', cfg.returnUrl || window.location.href.split('#')[0]);
				if (act !== 'snapshot') { hid('uzp_plan', cfg.plan); hid('uzp_plan_sig', cfg.plansig); }

				const msg = document.createElement('p');
				msg.className = 'uzp-confirm-msg';
				msg.textContent = c.note;
				form.appendChild(msg);

				const l1 = document.createElement('label');
				l1.appendChild(document.createTextNode(c.label));
				const inp = document.createElement('input');
				inp.type = 'text'; inp.name = c.field; inp.required = true; inp.maxLength = c.max; inp.pattern = c.pattern; inp.value = c.value;
				l1.appendChild(inp);
				form.appendChild(l1);

				const l2 = document.createElement('label');
				l2.style.marginTop = '10px';
				l2.appendChild(document.createTextNode('Description (optional)'));
				const ta = document.createElement('textarea');
				ta.name = 'description';
				l2.appendChild(ta);
				form.appendChild(l2);

				const row = document.createElement('div');
				row.className = 'uzp-dialog-actions';
				const cancel = document.createElement('button');
				cancel.type = 'button'; cancel.className = 'uzp-btn'; cancel.textContent = 'Cancel';
				const go = document.createElement('button');
				go.type = 'submit'; go.className = 'uzp-btn uzp-go'; go.textContent = c.go;
				row.appendChild(cancel); row.appendChild(go);
				form.appendChild(row);
				body.appendChild(form);

				const win = makeWindow({
					key: key, title: c.title + ' · ' + (btn.dataset.name || 'Instance') + ' · VMID ' + vmid,
					body: body, modal: true, maximizable: false, resizable: false, width: 460
				});

				cancel.addEventListener('click', function () { win.close(); });
				form.addEventListener('submit', function () { go.disabled = true; go.textContent = 'Working…'; });
				inp.focus();
				inp.select();
			}


			/* ---------- dark / light theme ---------- */
			function setTheme(theme) {
				theme = theme === 'light' ? 'light' : 'dark';
				root.dataset.theme = theme;
				root.querySelectorAll('[data-theme-label]').forEach(function (el) {
					el.textContent = theme === 'light' ? 'Light' : 'Dark';
				});
				try { localStorage.setItem('uzpve_theme', theme); } catch (e) {}
			}
			let savedTheme = 'dark';
			try { savedTheme = localStorage.getItem('uzpve_theme') || 'dark'; } catch (e) {}
			setTheme(savedTheme);

			/* ---------- grid / layer view ---------- */
			function setMode(mode) {
				mode = mode === 'layer' ? 'layer' : 'grid';
				root.dataset.mode = mode;
				root.querySelectorAll('[data-setmode]').forEach(function (b) { b.classList.toggle('active', b.dataset.setmode === mode); });
				try { localStorage.setItem('uzpve_mode', mode); } catch (e) {}
			}

			let savedMode = 'grid';
			try { savedMode = localStorage.getItem('uzpve_mode') || 'grid'; } catch (e) {}
			setMode(savedMode);

			/* ---------- delegated events (page + floating windows) ---------- */
			function onClick(e) {
				const t = e.target;

				const dj = t.closest('[data-job-dismiss]');
				if (dj) { e.preventDefault(); dismissJob(dj); return; }

				const conf = t.closest('button[data-confirm]');
				if (conf) {
					if (conf.disabled) return;
					e.preventDefault();
					ask(conf).then(function (yes) { if (yes) conf.form.requestSubmit(conf); });
					return;
				}

				const sh = t.closest('button[data-terminal]');
				if (sh) {
					e.preventDefault();
					if (!sh.disabled && cfg.terminal) openShell(sh);
					return;
				}

				const act = t.closest('[data-act]');
				if (act) { e.preventDefault(); openAction(act); return; }

				const op = t.closest('[data-open]');
				if (op) { e.preventDefault(); openCard(op.dataset.open); return; }

				const md = t.closest('[data-setmode]');
				if (md) { setMode(md.dataset.setmode); return; }

				const th = t.closest('[data-theme-toggle]');
				if (th) {
					e.preventDefault();
					setTheme(root.dataset.theme === 'light' ? 'dark' : 'light');
					return;
				}
			}

			function onToggle(e) {
				const d = e.target;
				if (d && d.matches && d.matches('details[data-history]') && d.open && !d.dataset.loaded) {
					d.dataset.loaded = '1';
					loadHistory(d);
				}
			}

			function onChange(e) {
				if (e.target.matches && e.target.matches('[data-timeframe]')) {
					const d = e.target.closest('details[data-history]');
					if (d && d.open) loadHistory(d);
				}
			}

			[root, layer].forEach(function (host) {
				host.addEventListener('click', onClick);
				host.addEventListener('toggle', onToggle, true); // "toggle" does not bubble
				host.addEventListener('change', onChange);
			});

			/* ---------- create-instance tabs ---------- */
			root.querySelectorAll('.uzp-tab').forEach(function (tab) {
				tab.addEventListener('click', function () {
					root.querySelectorAll('.uzp-tab').forEach(t => t.classList.remove('active'));
					root.querySelectorAll('.uzp-create-panel').forEach(p => p.classList.remove('is-active'));
					tab.classList.add('active');
					const target = root.querySelector('#' + root.dataset.uid + '-create-' + tab.dataset.uzpTab);
					if (target) target.classList.add('is-active');
				});
			});

			/* ---------- history (Proxmox RRD data) ---------- */
			const tileHtml = (key, label) =>
				'<div class="uzp-tile" data-tile="' + key + '"><div class="uzp-tile-h"><span>' + esc(label) + '</span><b data-val>—</b></div>' +
				'<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none"></svg></div>';

			async function loadHistory(details) {
				const grid = details.querySelector('[data-hist]');
				const tf = details.querySelector('[data-timeframe]').value;
				grid.innerHTML = '<div class="uzp-mini">Loading…</div>';

				try {
					const res = await fetch(cfg.metrics + [details.dataset.node, details.dataset.type, details.dataset.vmid].map(encodeURIComponent).join('/') + '?timeframe=' + encodeURIComponent(tf), {
						credentials: 'same-origin',
						headers: { 'X-WP-Nonce': cfg.nonce, 'Accept': 'application/json' }
					});
					const j = await res.json();
					if (!res.ok) throw new Error(j.message || 'Metrics request failed.');

					const rows = Array.isArray(j.data) ? j.data : [];
					if (rows.length < 2) { grid.innerHTML = '<div class="uzp-mini">No history for this timeframe yet.</div>'; return; }

					const n = v => Number(v) || 0;
					const cpu = rows.map(r => n(r.cpu) * 100);
					const mem = rows.map(r => n(r.maxmem) > 0 ? n(r.mem) / n(r.maxmem) * 100 : 0);
					const rx = rows.map(r => n(r.netin)), tx = rows.map(r => n(r.netout));
					const rd = rows.map(r => n(r.diskread)), wr = rows.map(r => n(r.diskwrite));
					const io = rows.map(r => n(r.host_iowait) * 100);
					const len = rows.length;

					grid.innerHTML = tileHtml('cpu', 'CPU') + tileHtml('mem', 'Memory') + tileHtml('net', 'Network') + tileHtml('disk', 'Disk I/O') + tileHtml('io', 'Host I/O delay');

					setTile(grid, 'cpu', [{ color: COLORS.cpu, data: cpu }], 100, 'peak ' + fmtPct(peak(cpu)), len);
					setTile(grid, 'mem', [{ color: COLORS.mem, data: mem }], 100, 'peak ' + fmtPct(peak(mem)), len);
					setTile(grid, 'net', [{ color: COLORS.rx, data: rx }, { color: COLORS.tx, data: tx }], 0, 'peak ↓ ' + fmtRate(peak(rx)) + ' ↑ ' + fmtRate(peak(tx)), len);
					setTile(grid, 'disk', [{ color: COLORS.rd, data: rd }, { color: COLORS.wr, data: wr }], 0, 'peak R ' + fmtRate(peak(rd)) + ' W ' + fmtRate(peak(wr)), len);
					setTile(grid, 'io', [{ color: COLORS.io, data: io }], 0, 'peak ' + peak(io).toFixed(2) + '%', len);
				} catch (e) {
					grid.innerHTML = '<div class="uzp-mini" style="color:#ffb9c1">Metrics error: ' + esc(e.message) + '</div>';
				}
			}

			const refreshBtn = root.querySelector('[data-refresh]');
			if (refreshBtn) {
				refreshBtn.addEventListener('click', function () {
					refreshBtn.disabled = true;
					refreshBtn.classList.add('is-spinning');
					window.location.reload();
				});
			}

			/* ---------- creation progress ---------- */
			const jobBox = root.querySelector('[data-jobbox]');
			let jobsReloading = false, jobFails = 0;

			function setJob(el, job) {
				el.dataset.state = job.state;
				const pct = Math.max(0, Math.min(100, Math.round(job.pct)));
				el.querySelector('[data-job-fill]').style.width = pct + '%';
				el.querySelector('[data-job-pct]').textContent = job.state === 'failed' ? 'Failed' : pct + '%';
				el.querySelector('[data-job-text]').textContent = job.state === 'failed' ? (job.error || 'Something went wrong.') : job.text;
				el.querySelector('[data-job-dismiss]').hidden = job.state !== 'failed';
			}

			async function dismissJob(btn) {
				const el = btn.closest('[data-job]');
				if (!el) return;
				try {
					await fetch(cfg.jobs + '/dismiss', {
						method: 'POST',
						credentials: 'same-origin',
						headers: { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json', 'Accept': 'application/json' },
						body: JSON.stringify({ id: el.dataset.job })
					});
				} catch (e) {}
				el.remove();
				if (jobBox && !jobBox.querySelector('[data-job]')) jobBox.remove();
			}

			async function pollJobs() {
				if (!jobBox) return;
				let again = false;

				try {
					const res = await fetch(cfg.jobs, { credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce, 'Accept': 'application/json' } });
					const j = await res.json();
					if (!res.ok) throw new Error(j.message || 'HTTP ' + res.status);
					jobFails = 0;

					const list = Array.isArray(j.jobs) ? j.jobs : [];
					let finished = false;

					list.forEach(function (job) {
						const el = jobBox.querySelector('[data-job="' + job.id + '"]');
						if (!el) return;
						if (job.state === 'done') { job.pct = 100; job.text = 'Ready! Loading your instance…'; finished = true; }
						if (job.state === 'running') again = true;
						setJob(el, job);
					});

					// A job that is no longer listed was finished (for example in another tab).
					jobBox.querySelectorAll('[data-job]').forEach(function (el) {
						if (el.dataset.state !== 'failed' && !list.some(x => x.id === el.dataset.job)) finished = true;
					});

					if (finished && !jobsReloading) {
						jobsReloading = true;
						setTimeout(function () { window.location.reload(); }, 1200);
						return;
					}
				} catch (e) {
					jobFails++;
					again = jobFails < 30;
				}

				if (again) setTimeout(pollJobs, 2000);
			}

			if (jobBox && cfg.jobs) pollJobs();

			/* ---------- demo countdown + optional warning ---------- */
			const demo = root.querySelector('[data-demo]');
			if (demo && Number(demo.dataset.end) > 0) {
				const end = Number(demo.dataset.end) * 1000;
				const offset = Number(demo.dataset.now) * 1000 - Date.now(); // server clock vs. this browser
				const warnMin = Number(demo.dataset.warn) || 0;
				const clock = demo.querySelector('[data-demo-clock]');
				const text = demo.querySelector('[data-demo-text]');
				const flagKey = 'uzpve_demo_warned_' + end;
				const pad = n => String(n).padStart(2, '0');
				let warned = false, reloaded = false;
				try { warned = !!sessionStorage.getItem(flagKey); } catch (e) {}

				function warnPopup(left) {
					const b = document.createElement('div');
					b.className = 'uzp-confirm';
					b.innerHTML = '<p class="uzp-confirm-msg"></p><div class="uzp-dialog-actions"><button type="button" class="uzp-btn uzp-go" data-ok>OK</button></div>';
					b.querySelector('p').textContent = 'Your demo ends in about ' + Math.max(1, Math.ceil(left / 60000)) + ' minutes. All demo containers and VMs will be deleted automatically.';
					const w = makeWindow({ title: 'Demo ending soon', body: b, width: 420, maximizable: false, resizable: false });
					b.querySelector('[data-ok]').addEventListener('click', function () { w.close(); });
				}

				function tick() {
					const left = end - (Date.now() + offset);

					if (left <= 0) {
						clock.textContent = '00:00';
						demo.classList.remove('is-warn');
						demo.classList.add('is-ended');
						text.textContent = 'Your demo has ended. Your demo instances are being deleted.';
						if (!reloaded) { reloaded = true; setTimeout(function () { window.location.reload(); }, 4000); }
						return;
					}

					const s = Math.ceil(left / 1000);
					clock.textContent = pad(Math.floor(s / 60)) + ':' + pad(s % 60);

					if (warnMin > 0 && left <= warnMin * 60000) {
						demo.classList.add('is-warn');
						text.textContent = 'Your demo is almost over. Everything you created will be deleted in:';
						if (!warned) {
							warned = true;
							try { sessionStorage.setItem(flagKey, '1'); } catch (e) {}
							warnPopup(left);
						}
					}
				}

				tick();
				setInterval(tick, 1000);
			}

			poll(); // always: this is also how a new instance is noticed when the page started out empty
		}

		function boot() { document.querySelectorAll('.urzone-pve[data-overview]').forEach(init); }

		if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
		else boot();
	})();