# Changelog — urZONE PVE Core

## 2.8.1 — 2026-10-25

### Fixed
- The API URL no longer has a built-in default address. A fresh install is "not configured" until you set your own.
- Installing this edition next to the Pro edition no longer crashes the site. The second copy shows a notice and stays off.

### Changed
- Added the GPL-2.0 `LICENSE` file and rewrote `COPYRIGHT.md` so it matches the GPL-2.0-or-later license in the plugin header.
- Replaced the outdated README with a new `README.md`.
- Removed the unused license-check file. The free edition does not check license keys.

## 2.8.0 — 2026-10-21

### New
- Free edition: the "urZONE Core Plans" admin page (where you set panels per plan) is not included. Plans use the built-in limits.

### Changed
- `urzone_pve_plans()` uses the built-in limits (1 / 5 / 10 / 20). The `urzone_pve_plan_limit` filter still has the final say.

## 2.7.1 — 2026-10-21

### Critical fixes
- Restored full original CSS structure (grid/layer mode, list view, jobs, demo banner, cards, buttons, charts).
- Fixed grid vs layer mode: grid hides list, layer hides grid cards (as designed).
- Fixed floating windows: `position: fixed` restored so drag / move works again.
- Fixed layer overlay z-index and pointer-events so windows are interactive.

### New
- Dark / Light mode toggle (button in header, preference saved in localStorage).

### Notes
- All original PHP functions and JS behaviour retained.
- Assets still in `assets/css/` and `assets/js/`.

## 2.7.0 — 2026-10-20
- Initial asset extraction and theme experiment (superseded by 2.7.1 for correctness).

## 2.6.1 — previous
- Core engine: Proxmox API, plans, ownership, demo mode, REST routes, renderer.
