Proxmox VE Trademark and Affiliation Disclaimer

urZONE PVE is an independent third-party WordPress plugin and service
integration created by Richard Charles Simmons, also known as Osiris Simmons
and Osiris83.

urZONE PVE is not affiliated with, endorsed by, sponsored by, authorized by,
maintained by, or otherwise associated with Proxmox Server Solutions GmbH, the
Proxmox project, or any of their affiliates.

“Proxmox” and “Proxmox VE” are trademarks or registered trademarks of Proxmox
Server Solutions GmbH. All rights in those marks are reserved by their
respective owner.

Any reference to Proxmox VE in urZONE PVE is solely for nominative and
descriptive purposes: to identify the third-party virtualization platform with
which urZONE PVE may interoperate. Such use does not imply any partnership,
certification, approval, endorsement, or commercial relationship.

Users are responsible for obtaining, installing, configuring, licensing where
applicable, securing, operating, and maintaining their own Proxmox VE
environment and any related servers, virtual machines, containers, networks,
storage, operating systems, templates, API credentials, and subscriptions.