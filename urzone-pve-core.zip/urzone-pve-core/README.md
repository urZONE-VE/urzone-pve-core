# urZONE PVE Core (free edition)

A WordPress plugin that lets your users create and manage their own Proxmox VE containers and virtual machines from a page on your site, without giving them Proxmox accounts.

- Live charts for CPU, memory, network and disk, with history from one hour up to a year
- Create LXC containers and VMs (from a template, from an ISO, or empty), with a progress bar
- Start, stop, restart, force stop and delete, each with a confirmation
- Each user sees only their own instances. Ownership is checked on the server
- Plans follow the WordPress user role, with instance limits and size caps
- Optional browser terminal for containers and VMs (needs a separate bridge service)
- Works on a single WordPress site or a multisite network

The free edition uses the built-in plan limits: Starter 1, Business 5, Pro 10, Agency 20 instances. It has no admin page for changing them (use the `urzone_pve_plan_limit` filter), and it does not check license keys.

## Requirements

- WordPress 5.8 or newer, PHP 7.4 or newer
- A Proxmox VE server whose API (port 8006, HTTPS) your WordPress server can reach
- Edit access to `wp-config.php`

## Install

1. Upload the plugin folder to `wp-content/plugins/` (or upload the zip under Plugins > Add New) and activate it. On a multisite network, network-activate it.
2. Create a Proxmox API token (below).
3. Enter the connection details (below).
4. Show the dashboard on a page (below).

## 1. Create the Proxmox API token

A dedicated user is safer than using `root@pam`:

1. Datacenter > Permissions > Users > Add: user `urzone`, realm `Proxmox VE authentication server`.
2. Datacenter > Permissions > Add > User Permission: path `/`, user `urzone@pve`, role `PVEAdmin`, Propagate ticked.
3. Datacenter > Permissions > API Tokens > Add: user `urzone@pve`, token ID `urzone`, and **untick Privilege Separation**. Copy the secret now. Proxmox shows it only once.

If Privilege Separation is on and the token lacks the `VM.Audit` permission, the guest list stays empty without an error.

## 2. Connect WordPress to Proxmox

Add these lines to `wp-config.php`, above the line that says "That's all, stop editing!":

```php
define( 'URZONE_PROXMOX_API_URL', 'https://YOUR_PVE_IP:8006/api2/json' );
define( 'URZONE_PROXMOX_API_USER', 'urzone@pve' );
define( 'URZONE_PROXMOX_API_TOKEN_ID', 'urzone' );
define( 'URZONE_PROXMOX_API_TOKEN_SECRET', 'YOUR_TOKEN_SECRET' );
```

Optional settings (node, storage, bridge, template and ISO storage, SSL verification, refresh time) are listed at the top of `urzone-pve-core.php`. If your Proxmox uses its default self-signed certificate, leave `URZONE_PROXMOX_SSLVERIFY` at `false`.

## 3. Show the dashboard

Core has no shortcode of its own: plan plugins add one and call `urzone_pve_render()`. For a quick start, add this to a small code-snippets plugin or your theme's `functions.php`, then put `[urzone_pve]` on a page:

```php
add_shortcode( 'urzone_pve', function ( $atts ) {
	return urzone_pve_render( $atts, 'legacy', 'urzone_pve' );
} );
```

Super admins see every instance. Other users get the plan that matches their WordPress role (`starter`, `business`, `pro`, `pro_reseller`, `agency` or `agency_reseller`). Users with none of these roles get the default limit (`URZONE_PROXMOX_MAX_INSTANCES`, 5 by default). Change the role names with `URZONE_PROXMOX_ROLE_PLANS` in `wp-config.php`.

## Web shell (optional)

The browser terminal needs a small bridge service (Node.js) behind an HTTPS address. WordPress issues a signed token that is valid for 30 seconds and works once. Set these two lines after the bridge is running:

```php
define( 'URZONE_TERMINAL_URL', 'wss://terms.yourdomain.com' );
define( 'URZONE_TERMINAL_SECRET', 'the-same-secret-as-the-bridge' );
```

## Security

- The API token stays on your WordPress server. The browser never sees it.
- Every action is checked against the logged-in user's ownership of that instance.
- Whoever opens a shell gets a root shell inside that container. Only give shells to users you trust.
- Report security problems privately through https://urzone.org rather than in a public issue.

## License and notices

GPL-2.0-or-later. See `LICENSE` and `COPYRIGHT.md`. urZONE PVE is an independent project and is not affiliated with or endorsed by Proxmox Server Solutions GmbH, the WordPress Foundation or Automattic. See `LEGAL.md` and `NOTICE.txt`.
