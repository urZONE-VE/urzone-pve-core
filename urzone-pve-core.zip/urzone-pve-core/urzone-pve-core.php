<?php
/**
 * Plugin Name: urZONE PVE Core
 * Plugin URI:  https://urzone.org/
 * Description: Core engine for self-service cloud infrastructure and virtualization management. Contains the Proxmox API, plans, ownership, demo, REST routes and renderer. It registers no shortcodes; plan plugins call urzone_pve_render().
 * Version:     2.8.1
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author:      Osiris Simmons (Osiris83)
 * Author URI:  https://urzone.org
 * Text Domain: urzone-pve-core
 * Domain Path: /languages
 *
 * Copyright © 2026 Richard Charles Simmons,
 * also known as Osiris Simmons and Osiris83.
 *
 * urZONE PVE is an independent third-party integration. It is not affiliated
 * with, endorsed by, sponsored by, or maintained by Proxmox Server Solutions
 * GmbH, the Proxmox project, the WordPress Foundation, or Automattic.
 *
 * “Proxmox” and “Proxmox VE” are trademarks or registered trademarks of
 * Proxmox Server Solutions GmbH. “WordPress” is a trademark of the
 * WordPress Foundation. All third-party marks are the property of their
 * respective owners and are used solely for identification and compatibility.
 *
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

// Only one copy of the Core engine can run: the free and Pro editions use the same function names.
if ( function_exists( 'urzone_pve_configured' ) ) {
	$urzone_pve_dup_notice = static function () {
		echo '<div class="notice notice-error"><p><strong>urZONE PVE:</strong> another copy of urZONE PVE Core is already active. Deactivate it first. Only one can run at a time.</p></div>';
	};

	add_action( 'admin_notices', $urzone_pve_dup_notice );
	add_action( 'network_admin_notices', $urzone_pve_dup_notice );

	return;
}

/*
|--------------------------------------------------------------------------
| Configuration: define these in wp-config.php
|--------------------------------------------------------------------------
|
| define( 'URZONE_PROXMOX_API_URL', 'https://YOUR_PVE_IP:8006/api2/json' );
| define( 'URZONE_PROXMOX_API_USER', 'root@pam' );
| define( 'URZONE_PROXMOX_API_TOKEN_ID', 'urzone' );
| define( 'URZONE_PROXMOX_API_TOKEN_SECRET', 'YOUR_TOKEN_SECRET' );
|
| Optional:
| define( 'URZONE_PROXMOX_SSLVERIFY', false );
| define( 'URZONE_PROXMOX_DEFAULT_NODE', 'pve' );
| define( 'URZONE_PROXMOX_DEFAULT_STORAGE', 'local-lvm' );
| define( 'URZONE_PROXMOX_DEFAULT_BRIDGE', 'vmbr0' );
| define( 'URZONE_PROXMOX_TEMPLATE_STORAGE', 'local' );
| define( 'URZONE_PROXMOX_ISO_STORAGE', 'local' );
| define( 'URZONE_PROXMOX_MAX_INSTANCES', 5 );   // only used by the legacy plan key
| define( 'URZONE_PROXMOX_POLL_SECONDS', 5 );    // live chart refresh
|
| Web shell (containers, and VMs that have a serial port with a login prompt on it):
| define( 'URZONE_TERMINAL_URL', 'wss://terms.urzone.org' );
| define( 'URZONE_TERMINAL_SECRET', 'LONG_RANDOM_STRING' );
|
| Plans (instance limit counts containers + VMs together). This core plugin has no
| shortcodes. A plan plugin shows the panel by calling:
|
|   urzone_pve_render( $atts, $plan_key, $tag )
|
| Plan keys:
|   admin     unlimited, sees every guest, super admins only
|   starter   1 instance
|   business  5 instances
|   pro       10 instances   (Pro Reseller)
|   agency    20 instances   (Agency Reseller)
|   demo      front-page demo: any logged-in user, time-limited, auto-deleted
|   legacy    super admin = admin view, everyone else = their role's plan
|
| Role-based plans: a customer's plan is decided by their WordPress role on their subsite.
| The plan key passed to urzone_pve_render() can never give more than the role allows.
| Map your role slugs:
|
| define( 'URZONE_PROXMOX_ROLE_PLANS', array(
|     'starter'  => 'starter',
|     'business' => 'business',
|     'pro'      => 'pro',
|     'agency'   => 'agency',
| ) );
|
| Demo settings (all optional):
| define( 'URZONE_PROXMOX_DEMO_MINUTES', 60 );           // length of one demo
| define( 'URZONE_PROXMOX_DEMO_WARN_MINUTES', 10 );      // warning before it ends (0 = off)
| define( 'URZONE_PROXMOX_DEMO_MAX_INSTANCES', 2 );      // instances per demo
| define( 'URZONE_PROXMOX_DEMO_COOLDOWN_MINUTES', 0 );   // wait before the same user can start another demo
| define( 'URZONE_PROXMOX_DEMO_BRIDGE', '' );            // e.g. an isolated bridge for demo guests
|
*/

/*
 * SECURITY: secrets are intentionally NOT defaulted here. Put the API token
 * secret and the terminal secret in wp-config.php only.
 */
$urzone_pve_defaults = array(
	'URZONE_PROXMOX_API_URL'          => '',
	'URZONE_PROXMOX_API_USER'         => 'root@pam',
	'URZONE_PROXMOX_API_TOKEN_ID'     => 'urzone',
	'URZONE_PROXMOX_API_TOKEN_SECRET' => '',
	'URZONE_PROXMOX_SSLVERIFY'        => false, // set true in production when using a trusted cert or proper CA
	'URZONE_PROXMOX_DEFAULT_NODE'     => 'pve',
	'URZONE_PROXMOX_DEFAULT_STORAGE'  => 'local-lvm',
	'URZONE_PROXMOX_DEFAULT_BRIDGE'   => 'vmbr0',
	'URZONE_PROXMOX_TEMPLATE_STORAGE' => 'local',
	'URZONE_PROXMOX_ISO_STORAGE'      => 'local',
	'URZONE_PROXMOX_MAX_INSTANCES'    => 5,
	'URZONE_PROXMOX_POLL_SECONDS'     => 5,
	'URZONE_TERMINAL_URL'             => '',
	'URZONE_TERMINAL_SECRET'          => '',
	'URZONE_PROXMOX_DEMO_MINUTES'          => 60,
	'URZONE_PROXMOX_DEMO_WARN_MINUTES'     => 10,
	'URZONE_PROXMOX_DEMO_MAX_INSTANCES'    => 2,
	'URZONE_PROXMOX_DEMO_COOLDOWN_MINUTES' => 0,
	'URZONE_PROXMOX_DEMO_BRIDGE'           => '',
);

foreach ( $urzone_pve_defaults as $urzone_pve_const => $urzone_pve_value ) {
	if ( ! defined( $urzone_pve_const ) ) {
		define( $urzone_pve_const, $urzone_pve_value );
	}
}
unset( $urzone_pve_defaults, $urzone_pve_const, $urzone_pve_value );

/*
|--------------------------------------------------------------------------
| Proxmox API
|--------------------------------------------------------------------------
*/

function urzone_pve_configured() {
	return (
		URZONE_PROXMOX_API_URL !== '' &&
		URZONE_PROXMOX_API_USER !== '' &&
		URZONE_PROXMOX_API_TOKEN_ID !== '' &&
		URZONE_PROXMOX_API_TOKEN_SECRET !== ''
	);
}

/** The shell needs a bridge URL (wss://) and a shared signing secret. */
function urzone_pve_terminal_configured() {
	return (
		URZONE_TERMINAL_SECRET !== '' &&
		stripos( trim( (string) URZONE_TERMINAL_URL ), 'wss://' ) === 0
	);
}

function urzone_pve_token_name() {
	$token = trim( (string) URZONE_PROXMOX_API_TOKEN_ID );

	if ( strpos( $token, '!' ) !== false ) {
		$parts = explode( '!', $token, 2 );
		return $parts[1];
	}

	return $token;
}

function urzone_pve_auth_header() {
	return sprintf(
		'PVEAPIToken=%s!%s=%s',
		URZONE_PROXMOX_API_USER,
		urzone_pve_token_name(),
		URZONE_PROXMOX_API_TOKEN_SECRET
	);
}

function urzone_pve_request( $method, $endpoint, $body = array(), $authenticated = true ) {
	if ( ! urzone_pve_configured() ) {
		return new WP_Error(
			'urzone_pve_not_configured',
			'Proxmox configuration is incomplete in wp-config.php.'
		);
	}

	if ( stripos( trim( (string) URZONE_PROXMOX_API_URL ), 'https://' ) !== 0 ) {
		return new WP_Error(
			'urzone_pve_insecure_url',
			'URZONE_PROXMOX_API_URL must start with https:// (the API token would otherwise be sent unencrypted). Currently configured: ' . sanitize_text_field( (string) URZONE_PROXMOX_API_URL )
		);
	}

	$paused = get_transient( 'uzpve_unreachable' );

	if ( $paused ) {
		return new WP_Error(
			'urzone_pve_unreachable',
			'Proxmox could not be reached a moment ago, so requests are paused for a few seconds. Last error: ' . sanitize_text_field( (string) $paused ) . ' Check the API URL and that this server can reach it.'
		);
	}

	$method = strtoupper( $method );
	$url    = rtrim( URZONE_PROXMOX_API_URL, '/' ) . '/' . ltrim( (string) $endpoint, '/' );

	$args = array(
		'method'      => $method,
		'timeout'     => $method === 'GET' ? 10 : 20,
		'redirection' => 0,
		'sslverify'   => (bool) URZONE_PROXMOX_SSLVERIFY,
		'headers'     => array(
			'Accept' => 'application/json',
		),
	);

	// /access/ticket is a login endpoint: Proxmox rejects it when an API token is sent.
	if ( $authenticated ) {
		$args['headers']['Authorization'] = urzone_pve_auth_header();
	}

	if ( ! empty( $body ) ) {
		// Proxmox expects GET/DELETE parameters in the query string.
		if ( in_array( $method, array( 'GET', 'DELETE' ), true ) ) {
			$url = add_query_arg( $body, $url );
		} else {
			$args['body'] = $body;
		}
	}

	$response = wp_remote_request( $url, $args );

	if ( is_wp_error( $response ) ) {
		// Connection-level failure: stop hammering an unreachable host for 30 seconds.
		set_transient( 'uzpve_unreachable', $response->get_error_message() ?: 'unknown connection error', 30 );

		return $response;
	}

	$status = wp_remote_retrieve_response_code( $response );
	$raw    = wp_remote_retrieve_body( $response );
	$data   = json_decode( $raw, true );

	if ( $status < 200 || $status >= 300 ) {
		$message = 'Proxmox returned HTTP ' . $status . '.';

		$reason = (string) wp_remote_retrieve_response_message( $response );

		if ( $reason !== '' && strpos( $message, $reason ) === false ) {
			$message .= ' (' . $reason . ')';
		}

		if ( 401 === $status || 403 === $status ) {
			$message .= ' Check the API token: URZONE_PROXMOX_API_USER, URZONE_PROXMOX_API_TOKEN_ID and URZONE_PROXMOX_API_TOKEN_SECRET must match a token in Proxmox (Datacenter > Permissions > API Tokens).';
		}

		if ( $status >= 300 && $status < 400 ) {
			$location = wp_remote_retrieve_header( $response, 'location' );
			$location = is_array( $location ) ? (string) reset( $location ) : (string) $location;
			$message .= ' Requested: ' . $url . '.';
			$message .= ' It redirected to ' . ( $location !== '' ? $location : 'another address' ) . '. Check URZONE_PROXMOX_API_URL (https, host, port, and /api2/json).';
		}

		if ( is_array( $data ) && ! empty( $data['message'] ) ) {
			$message = (string) $data['message'];
		}

		if ( is_array( $data ) && ! empty( $data['errors'] ) && is_array( $data['errors'] ) ) {
			$message .= ' ' . wp_json_encode( $data['errors'] );
		}

		return new WP_Error(
			'urzone_pve_http_error',
			sanitize_text_field( $message ),
			array(
				'status' => $status,
				'raw'    => $raw,
			)
		);
	}

	if ( ! is_array( $data ) ) {
		return new WP_Error( 'urzone_pve_invalid_json', 'Proxmox returned invalid JSON.' );
	}

	return $data;
}

function urzone_pve_get( $endpoint ) {
	return urzone_pve_request( 'GET', $endpoint );
}

function urzone_pve_post( $endpoint, $body = array() ) {
	return urzone_pve_request( 'POST', $endpoint, $body );
}

/**
 * Short-lived cache for read-only calls so many cards / many viewers do not
 * hammer the Proxmox host. Errors are never cached.
 */
function urzone_pve_get_cached( $endpoint, $ttl = 3 ) {
	$key    = 'uzpve_c_' . md5( $endpoint );
	$cached = get_transient( $key );

	if ( is_array( $cached ) ) {
		return $cached;
	}

	$result = urzone_pve_get( $endpoint );

	if ( ! is_wp_error( $result ) ) {
		set_transient( $key, $result, $ttl );
	}

	return $result;
}

/**
 * Wait for a Proxmox task (UPID). Returns true on OK, false on timeout,
 * WP_Error on failure.
 */
function urzone_pve_wait_task( $node, $upid, $max_seconds = 45 ) {
	$end = time() + $max_seconds;

	while ( time() < $end ) {
		$result = urzone_pve_get(
			'/nodes/' . rawurlencode( $node ) . '/tasks/' . rawurlencode( (string) $upid ) . '/status'
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ( $result['data']['status'] ?? '' ) === 'stopped' ) {
			$exit = (string) ( $result['data']['exitstatus'] ?? '' );
			return $exit === 'OK'
				? true
				: new WP_Error( 'urzone_pve_task_failed', 'Proxmox task failed: ' . sanitize_text_field( $exit ) );
		}

		sleep( 2 );
	}

	return false;
}

/*
|--------------------------------------------------------------------------
| Validation helpers
|--------------------------------------------------------------------------
*/

function urzone_pve_valid_node( $node ) {
	return (bool) preg_match( '/^[A-Za-z0-9._-]+$/', (string) $node );
}

function urzone_pve_valid_id( $value ) {
	return (bool) preg_match( '/^[A-Za-z0-9._-]+$/', (string) $value );
}

function urzone_pve_valid_hostname( $value ) {
	return (bool) preg_match( '/^[A-Za-z0-9][A-Za-z0-9.-]{0,62}$/', (string) $value );
}

function urzone_pve_valid_volid( $value ) {
	return (bool) preg_match( '#^[A-Za-z0-9._:/+-]+$#', (string) $value );
}

function urzone_pve_guest_path( $node, $type, $vmid ) {
	return '/nodes/' . rawurlencode( $node ) . '/' . rawurlencode( $type ) . '/' . absint( $vmid );
}

/*
|--------------------------------------------------------------------------
| Ownership
|--------------------------------------------------------------------------
|
| Each guest includes this in its Proxmox description:
|
| urZONE_OWNER_WP_ID=123
|
*/

/**
 * Full-access users see and manage every guest. On multisite that must be a super
 * admin only: every customer is the Administrator of their own subsite and has
 * manage_options there.
 */
function urzone_pve_is_admin() {
	$is_admin = is_multisite() ? is_super_admin() : current_user_can( 'manage_options' );

	return (bool) apply_filters( 'urzone_pve_is_admin', $is_admin );
}

function urzone_pve_owner_marker( $user_id ) {
	return 'urZONE_OWNER_WP_ID=' . absint( $user_id );
}

/** Remove any owner/demo markers (e.g. typed by a user into a description field). */
function urzone_pve_strip_markers( $description ) {
	return trim( preg_replace( '/urZONE_(?:OWNER_WP_ID|DEMO_EXPIRES)\s*=\s*\d*/i', '', (string) $description ) );
}

function urzone_pve_add_owner_marker( $description, $user_id, $demo_expires = 0 ) {
	$description = urzone_pve_strip_markers( $description );
	$out         = $description . "\n\n" . urzone_pve_owner_marker( $user_id );

	if ( $demo_expires > 0 ) {
		$out .= "\nurZONE_DEMO_EXPIRES=" . absint( $demo_expires );
	}

	return trim( $out );
}

/** Exact numeric match, so user 1 can never match markers of user 12, 13, ... */
function urzone_pve_parse_owner( $description ) {
	if ( preg_match( '/urZONE_OWNER_WP_ID=(\d+)(?!\d)/', (string) $description, $m ) ) {
		return absint( $m[1] );
	}

	return 0;
}

function urzone_pve_owner_cache_key( $node, $type, $vmid ) {
	return 'uzpve_own_' . md5( $node . '|' . $type . '|' . absint( $vmid ) );
}

function urzone_pve_forget_owner( $node, $type, $vmid ) {
	delete_transient( urzone_pve_owner_cache_key( $node, $type, $vmid ) );
}

/** Parses the demo expiry (unix time) from a description; 0 = not a demo guest. */
function urzone_pve_parse_demo( $description ) {
	if ( preg_match( '/urZONE_DEMO_EXPIRES=(\d+)(?!\d)/', (string) $description, $m ) ) {
		return absint( $m[1] );
	}

	return 0;
}

/** Owner and demo expiry for a guest, cached briefly. */
function urzone_pve_guest_meta( $node, $type, $vmid ) {
	$key    = urzone_pve_owner_cache_key( $node, $type, $vmid );
	$cached = get_transient( $key );

	if ( is_array( $cached ) && isset( $cached['owner'] ) ) {
		return $cached;
	}

	$config = urzone_pve_get( urzone_pve_guest_path( $node, $type, $vmid ) . '/config' );

	if ( is_wp_error( $config ) ) {
		return array( 'owner' => 0, 'demo' => 0 ); // Not cached on error.
	}

	$description = $config['data']['description'] ?? '';
	$meta        = array(
		'owner' => urzone_pve_parse_owner( $description ),
		'demo'  => urzone_pve_parse_demo( $description ),
	);

	set_transient( $key, $meta, $meta['owner'] > 0 ? 5 * MINUTE_IN_SECONDS : 15 );

	return $meta;
}

function urzone_pve_guest_owner( $node, $type, $vmid ) {
	$meta = urzone_pve_guest_meta( $node, $type, $vmid );

	return (int) $meta['owner'];
}

function urzone_pve_user_owns_guest( $user_id, $node, $type, $vmid ) {
	if ( ! in_array( $type, array( 'lxc', 'qemu' ), true ) || $vmid < 100 || ! $user_id ) {
		return false;
	}

	return urzone_pve_guest_owner( $node, $type, $vmid ) === absint( $user_id );
}

function urzone_pve_can_manage_guest( $node, $type, $vmid ) {
	if ( ! is_user_logged_in() ) {
		return false;
	}

	if ( urzone_pve_is_admin() ) {
		return true;
	}

	return urzone_pve_user_owns_guest( get_current_user_id(), $node, $type, $vmid );
}

/**
 * Guests on a node.
 *   $all  = true  -> every guest, but only for full-access users.
 *   $kind = 'plan' (default) -> the user's own guests, demo guests excluded
 *           'demo'           -> only the user's own demo guests
 *           'any'            -> the user's own guests, demo or not
 * Demo guests are kept apart so a demo can never use up a paid plan's slots.
 */
function urzone_pve_owned_guests( $node, $all = false, $kind = 'plan' ) {
	$result = urzone_pve_get_cached( '/cluster/resources', 3 );

	if ( is_wp_error( $result ) ) {
		return $result;
	}

	$guests     = array();
	$user_id    = get_current_user_id();
	$all_access = $all && urzone_pve_is_admin();

	foreach ( (array) ( $result['data'] ?? array() ) as $resource ) {
		if ( ! is_array( $resource ) ) {
			continue;
		}

		$type = (string) ( $resource['type'] ?? '' );
		$vmid = absint( $resource['vmid'] ?? 0 );

		if (
			( $resource['node'] ?? '' ) !== $node ||
			! in_array( $type, array( 'lxc', 'qemu' ), true ) ||
			$vmid < 100 ||
			! empty( $resource['template'] )
		) {
			continue;
		}

		if ( $all_access ) {
			$guests[] = $resource;
			continue;
		}

		if ( ! $user_id ) {
			continue;
		}

		$meta = urzone_pve_guest_meta( $node, $type, $vmid );

		if ( (int) $meta['owner'] !== $user_id ) {
			continue;
		}

		$is_demo = (int) $meta['demo'] > 0;

		if ( ( 'demo' === $kind && ! $is_demo ) || ( 'plan' === $kind && $is_demo ) ) {
			continue;
		}

		$guests[] = $resource;
	}

	usort(
		$guests,
		static function ( $a, $b ) {
			return (int) ( $a['vmid'] ?? 0 ) <=> (int) ( $b['vmid'] ?? 0 );
		}
	);

	return $guests;
}

function urzone_pve_next_vmid() {
	$result = urzone_pve_get( '/cluster/nextid' );

	return is_wp_error( $result ) ? 0 : absint( $result['data'] ?? 0 );
}

/*
|--------------------------------------------------------------------------
| Plans
|--------------------------------------------------------------------------
|
| The plan comes from the plan key passed to urzone_pve_render(). Because anyone
| who can edit a page could point it at a different plan, create forms carry a
| signed plan value that is verified again on the server when the form is submitted.
|
| To lock a customer to a smaller plan than the page says, use the filter:
|   add_filter( 'urzone_pve_plan_limit', function ( $limit, $plan, $user_id ) { ... }, 10, 3 );
|
*/

function urzone_pve_plans() {
	$plans = array(
		'admin'    => array( 'label' => 'Admin',           'limit' => 0,  'admin' => true ),
		'starter'  => array( 'label' => 'Starter',         'limit' => 1,  'admin' => false ),
		'business' => array( 'label' => 'Business',        'limit' => 5,  'admin' => false ),
		'pro'      => array( 'label' => 'Pro Reseller',    'limit' => 10, 'admin' => false ),
		'agency'   => array( 'label' => 'Agency Reseller', 'limit' => 20, 'admin' => false ),
		'demo'     => array( 'label' => 'Demo',            'limit' => max( 1, (int) URZONE_PROXMOX_DEMO_MAX_INSTANCES ), 'admin' => false, 'demo' => true ),
	);

	// Panels per plan (built-in limits).
	foreach ( urzone_pve_plan_limits() as $key => $limit ) {
		if ( isset( $plans[ $key ] ) ) {
			$plans[ $key ]['limit'] = $limit;
		}
	}

	return apply_filters( 'urzone_pve_plans', $plans );
}

/**
 * Role slug => plan key. Define URZONE_PROXMOX_ROLE_PLANS in wp-config.php to match the
 * role slugs your membership plugin creates, or use the 'urzone_pve_role_plans' filter.
 */
function urzone_pve_role_plans() {
	if ( defined( 'URZONE_PROXMOX_ROLE_PLANS' ) && is_array( URZONE_PROXMOX_ROLE_PLANS ) ) {
		$map = URZONE_PROXMOX_ROLE_PLANS;
	} else {
		$map = array(
			'starter'         => 'starter',
			'business'        => 'business',
			'pro'             => 'pro',
			'pro_reseller'    => 'pro',
			'agency'          => 'agency',
			'agency_reseller' => 'agency',
		);
	}

	return (array) apply_filters( 'urzone_pve_role_plans', $map );
}

/** The best plan key the current user's roles (on this site) grant, or '' if none. */
function urzone_pve_user_plan_key() {
	$user = wp_get_current_user();

	if ( ! $user || ! $user->exists() ) {
		return '';
	}

	$map        = urzone_pve_role_plans();
	$plans      = urzone_pve_plans();
	$best       = '';
	$best_limit = -1;

	foreach ( (array) $user->roles as $role ) {
		$key = (string) ( $map[ $role ] ?? '' );

		// A role can never grant the admin or demo plans.
		if ( $key === '' || empty( $plans[ $key ] ) || ! empty( $plans[ $key ]['admin'] ) || ! empty( $plans[ $key ]['demo'] ) ) {
			continue;
		}

		if ( (int) $plans[ $key ]['limit'] > $best_limit ) {
			$best       = $key;
			$best_limit = (int) $plans[ $key ]['limit'];
		}
	}

	return $best;
}

/**
 * Returns the plan array (with 'key'), or null when the current user may not use it.
 * Limited plans are capped by the user's role: a page can never grant more than the role.
 */
function urzone_pve_get_plan( $key ) {
	$key   = sanitize_key( (string) $key );
	$plans = urzone_pve_plans();

	if ( $key === 'legacy' ) {
		if ( urzone_pve_is_admin() ) {
			$plan        = $plans['admin'];
			$plan['key'] = 'admin';

			return $plan;
		}

		$role_key = urzone_pve_user_plan_key();

		if ( $role_key !== '' ) {
			$plan        = $plans[ $role_key ];
			$plan['key'] = $role_key;

			return $plan;
		}

		return array(
			'key'   => 'legacy',
			'label' => 'Account',
			'limit' => (int) URZONE_PROXMOX_MAX_INSTANCES,
			'admin' => false,
		);
	}

	if ( ! isset( $plans[ $key ] ) ) {
		return null;
	}

	$plan        = $plans[ $key ];
	$plan['key'] = $key;

	if ( ! empty( $plan['admin'] ) ) {
		return urzone_pve_is_admin() ? $plan : null;
	}

	if ( ! empty( $plan['demo'] ) ) {
		return $plan; // Open to every logged-in user.
	}

	if ( urzone_pve_is_admin() ) {
		return $plan; // Super admins can preview any plan page.
	}

	$role_key = urzone_pve_user_plan_key();

	if ( $role_key === '' ) {
		return null;
	}

	if ( (int) $plans[ $role_key ]['limit'] < (int) $plan['limit'] ) {
		$plan['limit'] = (int) $plans[ $role_key ]['limit'];
		$plan['label'] = $plans[ $role_key ]['label'];
		$plan['eff']   = $role_key; // the plan the user really has, used for the Snapshot / Clone / Template buttons
	}

	return $plan;
}

function urzone_pve_denied_message( $plan_key ) {
	$plans = urzone_pve_plans();

	if ( ! empty( $plans[ sanitize_key( (string) $plan_key ) ]['admin'] ) ) {
		return '<p>This page is for administrators only.</p>';
	}

	$user  = wp_get_current_user();
	$roles = ( $user && $user->exists() ) ? implode( ', ', array_map( 'sanitize_key', (array) $user->roles ) ) : '';

	return '<p>Your account does not have a plan that unlocks this page.' . ( $roles !== '' ? ' (role: ' . esc_html( $roles ) . ')' : '' ) . '</p>';
}

/** Effective instance limit; 0 = unlimited. */
function urzone_pve_plan_limit( $plan ) {
	if ( ! empty( $plan['admin'] ) ) {
		return 0;
	}

	return max( 0, (int) apply_filters( 'urzone_pve_plan_limit', (int) $plan['limit'], $plan, get_current_user_id() ) );
}

/**
 * Which Layer-view buttons a plan gets.
 *   Starter / Business              -> Snapshot
 *   Pro / Agency / Demo / Admin     -> Snapshot, Clone, Template
 * Uses the plan the user really has, so a Starter customer on a Pro page still only gets Snapshot.
 * Change it with the 'urzone_pve_plan_features' filter.
 */
function urzone_pve_plan_features( $plan ) {
	$eff = (string) ( $plan['eff'] ?? $plan['key'] ?? '' );

	if ( in_array( $eff, array( 'pro', 'agency', 'demo', 'admin' ), true ) ) {
		$features = array( 'snapshot', 'clone', 'template' );
	} else {
		$features = array( 'snapshot' );
	}

	return (array) apply_filters( 'urzone_pve_plan_features', $features, $plan );
}

/** Per-instance resource ceilings. The demo is deliberately small. */
function urzone_pve_caps( $plan ) {
	$caps = array( 'cores' => 64, 'memory' => 1048576, 'disk' => 2048 );

	if ( ! empty( $plan['demo'] ) ) {
		$caps = array( 'cores' => 2, 'memory' => 2048, 'disk' => 16 );
	}

	return (array) apply_filters( 'urzone_pve_caps', $caps, $plan );
}

function urzone_pve_plan_sig( $key ) {
	return hash_hmac( 'sha256', $key . '|' . get_current_user_id(), wp_salt( 'auth' ) );
}

/** Reads and verifies the signed plan from a create form. */
function urzone_pve_plan_from_request() {
	$key = sanitize_key( wp_unslash( $_POST['uzp_plan'] ?? '' ) );
	$sig = sanitize_text_field( wp_unslash( $_POST['uzp_plan_sig'] ?? '' ) );

	if ( $key === '' || $sig === '' || ! hash_equals( urzone_pve_plan_sig( $key ), $sig ) ) {
		return null;
	}

	return urzone_pve_get_plan( $key );
}

function urzone_pve_lock_key() {
	return 'uzpve_lock_' . get_current_user_id();
}

/*
|--------------------------------------------------------------------------
| Demo
|--------------------------------------------------------------------------
|
| A user's demo starts when they create their first demo instance and lasts
| URZONE_PROXMOX_DEMO_MINUTES. Every demo guest carries
|   urZONE_DEMO_EXPIRES=<unix time>
| in its description and is listed in a registry. A cleanup job (WP-Cron every
| minute, plus a cheap check whenever a demo page is viewed) stops and deletes
| expired demo guests. Guests without the marker are never touched.
|
*/

function urzone_pve_demo_seconds() {
	return max( 60, (int) URZONE_PROXMOX_DEMO_MINUTES * 60 );
}

function urzone_pve_demo_state( $user_id = 0 ) {
	$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
	$now     = time();
	$start   = (int) get_user_meta( $user_id, 'urzone_pve_demo_started', true );
	$end     = $start > 0 ? $start + urzone_pve_demo_seconds() : 0;
	$active  = $start > 0 && $now < $end;
	$next    = $start > 0 ? $end + max( 0, (int) URZONE_PROXMOX_DEMO_COOLDOWN_MINUTES ) * 60 : 0;

	return array(
		'now'       => $now,
		'start'     => $start,
		'end'       => $end,
		'active'    => $active,
		'next'      => $next,
		'can_start' => ! $active && $now >= $next,
	);
}

function urzone_pve_demo_registry() {
	$registry = get_site_option( 'urzone_pve_demo_registry', array() );

	return is_array( $registry ) ? $registry : array();
}

function urzone_pve_demo_register( $node, $type, $vmid, $expires ) {
	$registry = urzone_pve_demo_registry();

	$registry[ $node . '|' . $type . '|' . absint( $vmid ) ] = absint( $expires );

	update_site_option( 'urzone_pve_demo_registry', $registry );
}

/** Stops, then deletes, every expired demo guest. Safe to call often. */
function urzone_pve_demo_cleanup() {
	$registry = urzone_pve_demo_registry();

	if ( empty( $registry ) ) {
		return;
	}

	$now = time();
	$due = false;

	foreach ( $registry as $expires ) {
		if ( $now >= (int) $expires ) {
			$due = true;
			break;
		}
	}

	if ( ! $due || get_transient( 'uzpve_cleanup_lock' ) ) {
		return;
	}

	set_transient( 'uzpve_cleanup_lock', 1, 45 );

	$resources = urzone_pve_get( '/cluster/resources' );

	if ( is_wp_error( $resources ) ) {
		error_log( 'urZONE PVE demo cleanup: ' . $resources->get_error_message() ); // phpcs:ignore
		return;
	}

	$present = array();

	foreach ( (array) ( $resources['data'] ?? array() ) as $resource ) {
		if ( is_array( $resource ) && in_array( $resource['type'] ?? '', array( 'lxc', 'qemu' ), true ) ) {
			$present[ ( $resource['node'] ?? '' ) . '|' . $resource['type'] . '|' . absint( $resource['vmid'] ?? 0 ) ] = $resource;
		}
	}

	$handled = 0;

	foreach ( $registry as $key => $expires ) {
		if ( $now < (int) $expires ) {
			continue;
		}

		if ( ! isset( $present[ $key ] ) ) {
			unset( $registry[ $key ] ); // Already gone (deleted by the user or earlier).
			continue;
		}

		if ( $handled >= 10 ) {
			break;
		}

		$parts = explode( '|', (string) $key );

		if ( count( $parts ) !== 3 || ! urzone_pve_valid_node( $parts[0] ) || ! in_array( $parts[1], array( 'lxc', 'qemu' ), true ) || absint( $parts[2] ) < 100 ) {
			unset( $registry[ $key ] );
			continue;
		}

		list( $node, $type, $vmid ) = $parts;

		$base   = urzone_pve_guest_path( $node, $type, $vmid );
		$config = urzone_pve_get( $base . '/config' );

		if ( is_wp_error( $config ) ) {
			continue; // Try again on the next run.
		}

		$marker = urzone_pve_parse_demo( $config['data']['description'] ?? '' );

		if ( $marker < 1 ) {
			unset( $registry[ $key ] ); // Not a demo guest: never delete it.
			continue;
		}

		if ( $now < $marker ) {
			$registry[ $key ] = $marker;
			continue;
		}

		$handled++;

		if ( 'running' === ( $present[ $key ]['status'] ?? '' ) ) {
			// Stop now; it is deleted on the next run once it has stopped.
			urzone_pve_post( $base . '/status/stop' );
			continue;
		}

		$params = array( 'purge' => 1 );

		if ( 'qemu' === $type ) {
			$params['destroy-unreferenced-disks'] = 1;
		}

		$deleted = urzone_pve_request( 'DELETE', $base, $params );

		if ( is_wp_error( $deleted ) ) {
			error_log( 'urZONE PVE demo cleanup (VMID ' . absint( $vmid ) . '): ' . $deleted->get_error_message() ); // phpcs:ignore
			continue;
		}

		unset( $registry[ $key ] );
		urzone_pve_forget_owner( $node, $type, $vmid );
	}

	update_site_option( 'urzone_pve_demo_registry', $registry );
	delete_transient( 'uzpve_c_' . md5( '/cluster/resources' ) );
}

/*
|--------------------------------------------------------------------------
| IP address
|--------------------------------------------------------------------------
*/

function urzone_pve_guest_ip( $node, $type, $vmid, $status ) {
	if ( $status !== 'running' ) {
		return '';
	}

	$key    = 'uzpve_ip_' . md5( $node . '|' . $type . '|' . $vmid );
	$cached = get_transient( $key );

	if ( $cached !== false ) {
		return (string) $cached;
	}

	$base = urzone_pve_guest_path( $node, $type, $vmid );
	$ip   = '';

	if ( $type === 'lxc' ) {
		$result = urzone_pve_get( $base . '/interfaces' );

		if ( ! is_wp_error( $result ) ) {
			foreach ( (array) ( $result['data'] ?? array() ) as $iface ) {
				if ( ( $iface['name'] ?? '' ) === 'lo' || empty( $iface['inet'] ) ) {
					continue;
				}
				$ip = explode( '/', (string) $iface['inet'] )[0];
				break;
			}
		}
	} else {
		$result = urzone_pve_get( $base . '/agent/network-get-interfaces' );

		if ( ! is_wp_error( $result ) ) {
			foreach ( (array) ( $result['data']['result'] ?? array() ) as $iface ) {
				if ( ( $iface['name'] ?? '' ) === 'lo' ) {
					continue;
				}
				foreach ( (array) ( $iface['ip-addresses'] ?? array() ) as $addr ) {
					if (
						( $addr['ip-address-type'] ?? '' ) === 'ipv4' &&
						strpos( (string) ( $addr['ip-address'] ?? '' ), '127.' ) !== 0
					) {
						$ip = (string) $addr['ip-address'];
						break 2;
					}
				}
			}
		}
	}

	// Fallback: statically configured address in the guest config.
	if ( $ip === '' ) {
		$config = urzone_pve_get( $base . '/config' );

		if ( ! is_wp_error( $config ) ) {
			foreach ( (array) ( $config['data'] ?? array() ) as $name => $value ) {
				if ( preg_match( '/^net\d+$/', (string) $name ) && preg_match( '/ip=(\d{1,3}(?:\.\d{1,3}){3})/', (string) $value, $m ) ) {
					$ip = $m[1];
					break;
				}
			}
		}
	}

	$ip = filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';

	set_transient( $key, $ip, $ip === '' ? 15 : 60 );

	return $ip;
}

/*
|--------------------------------------------------------------------------
| Actions
|--------------------------------------------------------------------------
*/

function urzone_pve_redirect_notice( $key, $message ) {
	set_transient(
		'uzpve_notice_' . get_current_user_id(),
		array(
			'type'    => $key === 'urzone_pve_error' ? 'error' : 'success',
			'message' => (string) $message,
		),
		MINUTE_IN_SECONDS
	);

	// Go back to the page the form was on. Every form carries it in "uzp_return".
	$url = '';

	if ( ! empty( $_POST['uzp_return'] ) ) {
		$url = (string) wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['uzp_return'] ) ), '' );
	}

	if ( $url === '' ) {
		$url = wp_get_referer() ?: home_url( '/' );
	}

	$url = remove_query_arg( array( 'urzone_pve_message', 'urzone_pve_error' ), $url );

	wp_safe_redirect( $url );
	exit;
}

function urzone_pve_fail( $message ) {
	urzone_pve_redirect_notice( 'urzone_pve_error', $message );
}

function urzone_pve_ok( $message ) {
	urzone_pve_redirect_notice( 'urzone_pve_message', $message );
}

/** Runs after a successful create: rate-limit lock, demo session + registry, cache reset. */
function urzone_pve_after_create( $plan, $ctx = array(), $node = '', $type = '' ) {
	if ( urzone_pve_plan_limit( $plan ) > 0 ) {
		set_transient( urzone_pve_lock_key(), 1, 20 );
	}

	if ( ! empty( $plan['demo'] ) && ! empty( $ctx['demo_expires'] ) ) {
		$expires = (int) $ctx['demo_expires'];
		$state   = urzone_pve_demo_state();

		if ( ! $state['active'] ) {
			update_user_meta( get_current_user_id(), 'urzone_pve_demo_started', $expires - urzone_pve_demo_seconds() );
		}

		if ( $node !== '' && $type !== '' ) {
			urzone_pve_demo_register( $node, $type, $ctx['vmid'], $expires );
		}
	}

	if ( $node !== '' && $type !== '' && ! empty( $ctx['vmid'] ) ) {
		urzone_pve_forget_owner( $node, $type, $ctx['vmid'] );
	}

	delete_transient( 'uzpve_c_' . md5( '/cluster/resources' ) );
}

/** Admin plan may choose storage/bridge; every other plan gets the configured defaults. */
function urzone_pve_user_choice( $key, $default, $plan ) {
	if ( empty( $plan['admin'] ) ) {
		return $default;
	}

	$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ?? $default ) );

	return urzone_pve_valid_id( $value ) ? $value : '';
}

function urzone_pve_create_context( $node, $plan, $check_limit = true ) {
	$is_admin = ! empty( $plan['admin'] );
	$is_demo  = ! empty( $plan['demo'] );
	$limit    = urzone_pve_plan_limit( $plan );
	$expires  = 0;

	if ( $is_demo ) {
		$state = urzone_pve_demo_state();
		$now   = time();

		if ( $state['active'] ) {
			if ( $state['end'] - $now < 300 ) {
				urzone_pve_fail( 'Your demo ends in less than 5 minutes, so no new instances can be created. Your demo instances will be deleted automatically.' );
			}

			$expires = $state['end'];
		} elseif ( ! $state['can_start'] ) {
			urzone_pve_fail( 'Your next demo is available in ' . max( 1, (int) ceil( ( $state['next'] - $now ) / 60 ) ) . ' minute(s).' );
		} else {
			$expires = $now + urzone_pve_demo_seconds();
		}
	}

	if ( $limit > 0 && $check_limit ) {
		if ( get_transient( urzone_pve_lock_key() ) ) {
			urzone_pve_fail( 'Your previous request is still being processed. Wait a few seconds and try again.' );
		}

		$owned = urzone_pve_owned_guests( $node, false, $is_demo ? 'demo' : 'plan' );

		if ( is_wp_error( $owned ) ) {
			urzone_pve_fail( 'Could not verify your instance count: ' . $owned->get_error_message() );
		}

		if ( count( $owned ) >= $limit ) {
			urzone_pve_fail(
				'Your ' . $plan['label'] . ' plan allows ' . $limit . ' instance' . ( $limit === 1 ? '' : 's' ) . '. Delete one before creating another.'
			);
		}
	}

	$vmid = $is_admin ? absint( $_POST['vmid'] ?? 0 ) : 0;

	if ( $vmid < 100 ) {
		$vmid = urzone_pve_next_vmid();
	}

	$description    = sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) );
	$default_bridge = ( $is_demo && URZONE_PROXMOX_DEMO_BRIDGE !== '' ) ? URZONE_PROXMOX_DEMO_BRIDGE : URZONE_PROXMOX_DEFAULT_BRIDGE;

	return array(
		'vmid'         => $vmid,
		'storage'      => urzone_pve_user_choice( 'storage', URZONE_PROXMOX_DEFAULT_STORAGE, $plan ),
		'bridge'       => urzone_pve_user_choice( 'bridge', $default_bridge, $plan ),
		'description'  => urzone_pve_add_owner_marker( $description, get_current_user_id(), $expires ),
		'start'        => ! empty( $_POST['start'] ) ? 1 : 0,
		'demo_expires' => $expires,
	);
}

function urzone_pve_num( $key, $default, $min, $max ) {
	return max( $min, min( $max, absint( $_POST[ $key ] ?? $default ) ) );
}

function urzone_pve_do_guest_action( $action, $node ) {
	$type = sanitize_key( wp_unslash( $_POST['guest_type'] ?? '' ) );
	$vmid = absint( $_POST['vmid'] ?? 0 );

	if ( ! in_array( $type, array( 'lxc', 'qemu' ), true ) || $vmid < 100 ) {
		urzone_pve_fail( 'Invalid instance action.' );
	}

	if ( ! urzone_pve_can_manage_guest( $node, $type, $vmid ) ) {
		urzone_pve_fail( 'You do not own that instance.' );
	}

	$base = urzone_pve_guest_path( $node, $type, $vmid );

	if ( $action === 'delete' ) {
		$current = urzone_pve_get( $base . '/status/current' );

		if ( is_wp_error( $current ) ) {
			urzone_pve_fail( $current->get_error_message() );
		}

		if ( ( $current['data']['status'] ?? '' ) !== 'stopped' ) {
			urzone_pve_fail( 'Stop VMID ' . $vmid . ' before deleting it.' );
		}

		$params = array( 'purge' => 1 );

		if ( $type === 'qemu' ) {
			$params['destroy-unreferenced-disks'] = 1;
		}

		$result = urzone_pve_request( 'DELETE', $base, $params );

		if ( is_wp_error( $result ) ) {
			urzone_pve_fail( $result->get_error_message() );
		}

		urzone_pve_forget_owner( $node, $type, $vmid );
		delete_transient( 'uzpve_c_' . md5( '/cluster/resources' ) );
		urzone_pve_ok( 'Deletion queued for VMID ' . $vmid . '.' );
	}

	// Graceful stop = shutdown with a forced fallback after 30 seconds.
	$body   = $action === 'shutdown' ? array( 'forceStop' => 1, 'timeout' => 30 ) : array();
	$result = urzone_pve_post( $base . '/status/' . $action, $body );

	if ( is_wp_error( $result ) ) {
		urzone_pve_fail( $result->get_error_message() );
	}

	set_transient( 'uzpve_ip_' . md5( $node . '|' . $type . '|' . $vmid ), '', 5 );

	urzone_pve_ok( ucfirst( $action ) . ' queued for VMID ' . $vmid . '.' );
}

function urzone_pve_do_create_lxc( $node, $plan ) {
	$ctx      = urzone_pve_create_context( $node, $plan );
	$caps     = urzone_pve_caps( $plan );
	$hostname = sanitize_text_field( wp_unslash( $_POST['hostname'] ?? '' ) );
	$template = sanitize_text_field( wp_unslash( $_POST['template'] ?? '' ) );
	$password = (string) wp_unslash( $_POST['password'] ?? '' );
	$ssh_keys = sanitize_textarea_field( wp_unslash( $_POST['ssh_keys'] ?? '' ) );
	$nesting  = ! empty( $_POST['nesting'] ) ? 1 : 0;

	if (
		$ctx['vmid'] < 100 ||
		! urzone_pve_valid_hostname( $hostname ) ||
		$ctx['storage'] === '' ||
		$ctx['bridge'] === '' ||
		strlen( $password ) < 8 ||
		! urzone_pve_valid_volid( $template ) ||
		strpos( $template, URZONE_PROXMOX_TEMPLATE_STORAGE . ':vztmpl/' ) !== 0
	) {
		urzone_pve_fail( 'Complete all required LXC fields (password of 8+ characters) and select a valid template.' );
	}

	$payload = array(
		'vmid'         => $ctx['vmid'],
		'hostname'     => $hostname,
		'ostemplate'   => $template,
		'rootfs'       => $ctx['storage'] . ':' . urzone_pve_num( 'disk_gb', 8, 1, $caps['disk'] ),
		'cores'        => urzone_pve_num( 'cores', 1, 1, $caps['cores'] ),
		'memory'       => urzone_pve_num( 'memory', 1024, 256, $caps['memory'] ),
		'net0'         => 'name=eth0,bridge=' . $ctx['bridge'] . ',ip=dhcp',
		'password'     => $password,
		'description'  => $ctx['description'],
		'unprivileged' => 1,
		'features'     => 'nesting=' . $nesting,
		'start'        => $ctx['start'],
	);

	if ( $ssh_keys !== '' ) {
		$payload['ssh-public-keys'] = $ssh_keys;
	}

	$result = urzone_pve_post( '/nodes/' . rawurlencode( $node ) . '/lxc', $payload );

	if ( is_wp_error( $result ) ) {
		urzone_pve_fail( $result->get_error_message() );
	}

	urzone_pve_after_create( $plan, $ctx, $node, 'lxc' );
	urzone_pve_add_job( (string) ( $result['data'] ?? '' ), $node, 'lxc', $ctx['vmid'], $hostname );
	urzone_pve_ok( 'Creating container VMID ' . $ctx['vmid'] . '. Follow the progress bar below.' );
}

function urzone_pve_do_create_vm( $node, $mode, $plan ) {
	$ctx     = urzone_pve_create_context( $node, $plan );
	$caps    = urzone_pve_caps( $plan );
	$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$iso     = sanitize_text_field( wp_unslash( $_POST['iso'] ?? '' ) );
	$nesting = ! empty( $_POST['nesting'] ) ? 1 : 0;

	if (
		$ctx['vmid'] < 100 ||
		! urzone_pve_valid_hostname( $name ) ||
		$ctx['storage'] === '' ||
		$ctx['bridge'] === ''
	) {
		urzone_pve_fail( 'Complete all required virtual-machine fields.' );
	}

	$payload = array(
		'vmid'        => $ctx['vmid'],
		'name'        => $name,
		'cores'       => urzone_pve_num( 'cores', 2, 1, $caps['cores'] ),
		'memory'      => urzone_pve_num( 'memory', 2048, 512, $caps['memory'] ),
		'scsihw'      => 'virtio-scsi-pci',
		'scsi0'       => $ctx['storage'] . ':' . urzone_pve_num( 'disk_gb', 32, 4, $caps['disk'] ) . ',format=raw',
		'net0'        => 'virtio,bridge=' . $ctx['bridge'],
		'ostype'      => 'l26',
		'agent'       => 1,
		'serial0'     => 'socket', // lets the web shell attach to the VM
		'description' => $ctx['description'],
		'start'       => $ctx['start'],
	);

	if ( $nesting ) {
		$payload['cpu'] = 'host'; // exposes virtualization extensions so the VM can run its own VMs
	}

	if ( $mode === 'iso' ) {
		if (
			! urzone_pve_valid_volid( $iso ) ||
			strpos( $iso, URZONE_PROXMOX_ISO_STORAGE . ':iso/' ) !== 0
		) {
			urzone_pve_fail( 'Select a valid ISO.' );
		}

		$payload['ide2'] = $iso . ',media=cdrom';
		$payload['boot'] = 'order=ide2;scsi0;net0';
	} else {
		$payload['boot'] = 'order=scsi0;net0';
	}

	$result = urzone_pve_post( '/nodes/' . rawurlencode( $node ) . '/qemu', $payload );

	if ( is_wp_error( $result ) ) {
		urzone_pve_fail( $result->get_error_message() );
	}

	urzone_pve_after_create( $plan, $ctx, $node, 'qemu' );
	urzone_pve_add_job( (string) ( $result['data'] ?? '' ), $node, 'qemu', $ctx['vmid'], $name );
	urzone_pve_ok( 'Creating virtual machine VMID ' . $ctx['vmid'] . '. Follow the progress bar below.' );
}

/** Every VM template on the node (cached briefly). */
function urzone_pve_vm_templates_raw( $node ) {
	$result = urzone_pve_get_cached( '/nodes/' . rawurlencode( $node ) . '/qemu', 30 );

	if ( is_wp_error( $result ) ) {
		return array();
	}

	return array_values(
		array_filter(
			(array) ( $result['data'] ?? array() ),
			static function ( $vm ) {
				return is_array( $vm ) && ! empty( $vm['template'] );
			}
		)
	);
}

/**
 * Templates the current user may clone: ones you made yourself and ones with no owner
 * (the templates you set up as the host). Other customers' templates are never listed.
 * Administrators see all.
 */
function urzone_pve_vm_templates( $node ) {
	$uid      = get_current_user_id();
	$is_admin = urzone_pve_is_admin();
	$out      = array();

	foreach ( urzone_pve_vm_templates_raw( $node ) as $vm ) {
		if ( $is_admin ) {
			$out[] = $vm;
			continue;
		}

		$owner = urzone_pve_guest_owner( $node, 'qemu', absint( $vm['vmid'] ?? 0 ) );

		if ( 0 === $owner || $owner === $uid ) {
			$out[] = $vm;
		}
	}

	return $out;
}

function urzone_pve_do_clone_vm( $node, $plan ) {
	$ctx           = urzone_pve_create_context( $node, $plan );
	$caps          = urzone_pve_caps( $plan );
	$template_vmid = absint( $_POST['template_vmid'] ?? 0 );
	$name          = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$cores         = urzone_pve_num( 'cores', 2, 1, $caps['cores'] );
	$memory        = urzone_pve_num( 'memory', 2048, 512, $caps['memory'] );
	$nesting       = ! empty( $_POST['nesting'] ) ? 1 : 0;

	if ( $template_vmid < 100 || $ctx['vmid'] < 100 || $ctx['storage'] === '' || ! urzone_pve_valid_hostname( $name ) ) {
		urzone_pve_fail( 'Complete all required VM template fields.' );
	}

	$allowed = wp_list_pluck( urzone_pve_vm_templates( $node ), 'vmid' );

	if ( ! in_array( $template_vmid, array_map( 'absint', $allowed ), true ) ) {
		urzone_pve_fail( 'That is not an available VM template.' );
	}

	$base  = '/nodes/' . rawurlencode( $node ) . '/qemu/';
	$clone = urzone_pve_post(
		$base . $template_vmid . '/clone',
		array(
			'newid'       => $ctx['vmid'],
			'name'        => $name,
			'full'        => 1,
			'storage'     => $ctx['storage'],
			'description' => $ctx['description'], // Ownership (and demo expiry) is set immediately, not after the clone.
		)
	);

	if ( is_wp_error( $clone ) ) {
		urzone_pve_fail( $clone->get_error_message() );
	}

	urzone_pve_after_create( $plan, $ctx, $node, 'qemu' );

	// The disk copy can take a while, so it is not waited for here. The progress bar follows the task, and
	// CPU / memory / nesting / serial port / start are applied by urzone_pve_job_status() when the copy finishes.
	urzone_pve_add_job(
		(string) ( $clone['data'] ?? '' ),
		$node,
		'qemu',
		$ctx['vmid'],
		$name,
		array(
			'cores'   => $cores,
			'memory'  => $memory,
			'nesting' => $nesting,
			'start'   => $ctx['start'],
		)
	);

	urzone_pve_ok( 'Cloning virtual machine VMID ' . $ctx['vmid'] . '. Follow the progress bar below.' );
}

/*
|--------------------------------------------------------------------------
| Snapshot / Clone / Template (buttons in the Layer view)
|--------------------------------------------------------------------------
*/

/** The instance an action is about, after checking that the user owns it. Returns array( type, vmid ). */
function urzone_pve_guest_from_post( $node ) {
	$type = sanitize_key( wp_unslash( $_POST['guest_type'] ?? '' ) );
	$vmid = absint( $_POST['vmid'] ?? 0 );

	if ( ! in_array( $type, array( 'lxc', 'qemu' ), true ) || $vmid < 100 ) {
		urzone_pve_fail( 'Invalid instance action.' );
	}

	if ( ! urzone_pve_can_manage_guest( $node, $type, $vmid ) ) {
		urzone_pve_fail( 'You do not own that instance.' );
	}

	return array( $type, $vmid );
}

function urzone_pve_do_snapshot( $node ) {
	list( $type, $vmid ) = urzone_pve_guest_from_post( $node );

	$name = sanitize_text_field( wp_unslash( $_POST['snap_name'] ?? '' ) );
	$desc = sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) );

	if ( ! preg_match( '/^[A-Za-z][A-Za-z0-9_-]{0,39}$/', $name ) ) {
		urzone_pve_fail( 'A snapshot name must start with a letter and use only letters, numbers, - and _ (40 characters at most).' );
	}

	$base = urzone_pve_guest_path( $node, $type, $vmid );

	// Optional cap per instance. 0 (the default) = no cap. Set with the 'urzone_pve_max_snapshots' filter.
	$max = (int) apply_filters( 'urzone_pve_max_snapshots', 0, $type, $vmid );

	if ( $max > 0 && ! urzone_pve_is_admin() ) {
		$list = urzone_pve_get( $base . '/snapshot' );

		if ( is_wp_error( $list ) ) {
			urzone_pve_fail( $list->get_error_message() );
		}

		$count = 0;

		foreach ( (array) ( $list['data'] ?? array() ) as $snap ) {
			if ( is_array( $snap ) && 'current' !== ( $snap['name'] ?? '' ) ) {
				$count++;
			}
		}

		if ( $count >= $max ) {
			urzone_pve_fail( 'This instance already has ' . $max . ' snapshot' . ( 1 === $max ? '' : 's' ) . '.' );
		}
	}

	$body = array( 'snapname' => $name );

	if ( $desc !== '' ) {
		$body['description'] = $desc;
	}

	$result = urzone_pve_post( $base . '/snapshot', $body );

	if ( is_wp_error( $result ) ) {
		urzone_pve_fail( $result->get_error_message() );
	}

	urzone_pve_ok( 'Snapshot "' . $name . '" queued for VMID ' . $vmid . '.' );
}

/** Templates on this node that belong to the current user. */
function urzone_pve_count_user_templates( $node ) {
	$count = 0;
	$uid   = get_current_user_id();

	foreach ( urzone_pve_vm_templates_raw( $node ) as $vm ) {
		if ( urzone_pve_guest_owner( $node, 'qemu', absint( $vm['vmid'] ?? 0 ) ) === $uid ) {
			$count++;
		}
	}

	return $count;
}

/**
 * Clone = a full copy of the instance. Template = a full copy that is then turned into a
 * template (the original is left alone). The copy runs as a progress bar, like creating an instance.
 */
function urzone_pve_do_copy_guest( $node, $plan, $as_template ) {
	$feature = $as_template ? 'template' : 'clone';

	if ( ! in_array( $feature, urzone_pve_plan_features( $plan ), true ) ) {
		urzone_pve_fail( 'Your plan does not include this feature.' );
	}

	list( $type, $source ) = urzone_pve_guest_from_post( $node );

	if ( $as_template && 'qemu' !== $type ) {
		urzone_pve_fail( 'Templates can only be made from virtual machines.' );
	}

	$name = sanitize_text_field( wp_unslash( $_POST['copy_name'] ?? '' ) );

	if ( ! urzone_pve_valid_hostname( $name ) ) {
		urzone_pve_fail( 'Enter a name that starts with a letter or number and uses only letters, numbers, dots and dashes.' );
	}

	$base    = urzone_pve_guest_path( $node, $type, $source );
	$current = urzone_pve_get( $base . '/status/current' );

	if ( is_wp_error( $current ) ) {
		urzone_pve_fail( $current->get_error_message() );
	}

	$status = (string) ( $current['data']['status'] ?? '' );

	if ( 'lxc' === $type && 'stopped' !== $status ) {
		urzone_pve_fail( 'Stop the container before cloning it.' );
	}

	if ( $as_template && 'stopped' !== $status ) {
		urzone_pve_fail( 'Stop the virtual machine before making a template from it.' );
	}

	if ( $as_template && ! urzone_pve_is_admin() ) {
		$max = (int) apply_filters( 'urzone_pve_max_templates', 3 );

		if ( $max > 0 && urzone_pve_count_user_templates( $node ) >= $max ) {
			urzone_pve_fail( 'You already have ' . $max . ' template' . ( 1 === $max ? '' : 's' ) . '.' );
		}
	}

	// A clone uses an instance slot. A template does not (it is not counted as an instance).
	$ctx = urzone_pve_create_context( $node, $plan, ! $as_template );

	if ( $ctx['vmid'] < 100 || $ctx['storage'] === '' ) {
		urzone_pve_fail( 'Could not get a free VMID from Proxmox.' );
	}

	$params = array(
		'newid'       => $ctx['vmid'],
		'full'        => 1,
		'storage'     => $ctx['storage'],
		'description' => $ctx['description'], // Ownership (and demo expiry) is set straight away.
	);

	$params[ 'lxc' === $type ? 'hostname' : 'name' ] = $name;

	$result = urzone_pve_post( $base . '/clone', $params );

	if ( is_wp_error( $result ) ) {
		urzone_pve_fail( $result->get_error_message() );
	}

	urzone_pve_after_create( $plan, $ctx, $node, $type );
	urzone_pve_add_job( (string) ( $result['data'] ?? '' ), $node, $type, $ctx['vmid'], $name, $as_template ? array( 'template' => 1 ) : array() );

	urzone_pve_ok( ( $as_template ? 'Making a template from VMID ' : 'Cloning VMID ' ) . $source . ' as VMID ' . $ctx['vmid'] . '. Follow the progress bar below.' );
}

function urzone_pve_handle_actions() {
	if ( empty( $_POST['urzone_pve_action'] ) ) {
		return;
	}

	if ( ! is_user_logged_in() ) {
		wp_die( 'You must be logged in.', '', array( 'response' => 403 ) );
	}

	$nonce = sanitize_text_field( wp_unslash( $_POST['urzone_pve_nonce'] ?? '' ) );

	if ( ! wp_verify_nonce( $nonce, 'urzone_pve_action' ) ) {
		wp_die( 'Security check failed. Go back and reload the page.', '', array( 'response' => 403 ) );
	}

	$action = sanitize_key( wp_unslash( $_POST['urzone_pve_action'] ) );
	$node   = sanitize_text_field( wp_unslash( $_POST['node'] ?? URZONE_PROXMOX_DEFAULT_NODE ) );

	if ( ! urzone_pve_valid_node( $node ) ) {
		urzone_pve_fail( 'Invalid Proxmox node.' );
	}

	if ( in_array( $action, array( 'start', 'shutdown', 'reboot', 'stop', 'delete' ), true ) ) {
		urzone_pve_do_guest_action( $action, $node );
	}

	if ( 'snapshot' === $action ) {
		urzone_pve_do_snapshot( $node );
	}

	if ( ! in_array( $action, array( 'create_lxc', 'create_vm_iso', 'create_vm_empty', 'clone_vm_template', 'clone_guest', 'make_template' ), true ) ) {
		return;
	}

	// Creation is where plan limits apply: the plan must carry a valid signature.
	$plan = urzone_pve_plan_from_request();

	if ( ! $plan ) {
		urzone_pve_fail( 'Your plan could not be verified. Reload the page and try again.' );
	}

	switch ( $action ) {
		case 'create_lxc':
			urzone_pve_do_create_lxc( $node, $plan );
			break;
		case 'create_vm_iso':
			urzone_pve_do_create_vm( $node, 'iso', $plan );
			break;
		case 'create_vm_empty':
			urzone_pve_do_create_vm( $node, 'empty', $plan );
			break;
		case 'clone_vm_template':
			urzone_pve_do_clone_vm( $node, $plan );
			break;
		case 'clone_guest':
			urzone_pve_do_copy_guest( $node, $plan, false );
			break;
		case 'make_template':
			urzone_pve_do_copy_guest( $node, $plan, true );
			break;
	}
}

add_action( 'template_redirect', 'urzone_pve_handle_actions' );

/*
|--------------------------------------------------------------------------
| Creation progress
|--------------------------------------------------------------------------
|
| Creating an instance is a Proxmox task that can take a while. Each create is remembered
| as a "job" for that user. The page shows a progress bar for it and polls /jobs until the
| Proxmox task finishes, then reloads so the new instance appears.
|
*/

function urzone_pve_jobs_key() {
	return 'uzpve_jobs_' . get_current_user_id();
}

function urzone_pve_jobs_get() {
	$jobs = get_transient( urzone_pve_jobs_key() );

	return is_array( $jobs ) ? $jobs : array();
}

function urzone_pve_jobs_save( $jobs ) {
	if ( empty( $jobs ) ) {
		delete_transient( urzone_pve_jobs_key() );
		return;
	}

	set_transient( urzone_pve_jobs_key(), $jobs, 2 * HOUR_IN_SECONDS );
}

function urzone_pve_job_id( $upid ) {
	return substr( md5( (string) $upid ), 0, 12 );
}

function urzone_pve_add_job( $upid, $node, $type, $vmid, $name, $post = array() ) {
	$upid = (string) $upid;

	if ( strpos( $upid, 'UPID:' ) !== 0 ) {
		return;
	}

	$jobs          = urzone_pve_jobs_get();
	$jobs[ $upid ] = array(
		'node'      => (string) $node,
		'type'      => (string) $type,
		'vmid'      => absint( $vmid ),
		'name'      => (string) $name,
		'started'   => time(),
		'post'      => (array) $post,
		'post_done' => false,
		'error'     => '',
	);

	urzone_pve_jobs_save( array_slice( $jobs, -5, null, true ) );
}

/** The last few lines of a Proxmox task log. */
function urzone_pve_task_log_tail( $node, $upid, $lines = 25 ) {
	$base  = '/nodes/' . rawurlencode( $node ) . '/tasks/' . rawurlencode( $upid ) . '/log';
	$first = urzone_pve_get( $base . '?start=0&limit=1' );

	if ( is_wp_error( $first ) ) {
		return array();
	}

	$total = (int) ( $first['total'] ?? 0 );

	if ( $total > $lines ) {
		$tail = urzone_pve_get( $base . '?start=' . ( $total - $lines ) . '&limit=' . $lines );
		$rows = is_wp_error( $tail ) ? array() : (array) ( $tail['data'] ?? array() );
	} elseif ( $total === 0 && ! empty( $first['data'] ) ) {
		$all  = urzone_pve_get( $base . '?start=0&limit=500' ); // total not reported: read what there is
		$rows = is_wp_error( $all ) ? array() : array_slice( (array) ( $all['data'] ?? array() ), -$lines );
	} else {
		$rows = (array) ( $first['data'] ?? array() );
	}

	$out = array();

	foreach ( $rows as $row ) {
		$out[] = (string) ( is_array( $row ) ? ( $row['t'] ?? '' ) : '' );
	}

	return $out;
}

/**
 * Progress for a running task: a real percentage when Proxmox logs one (disk copies do),
 * otherwise the furthest known stage, otherwise an estimate from elapsed time.
 * Only friendly stage names are returned, never raw log lines.
 */
function urzone_pve_job_progress( $job, $log ) {
	$elapsed = max( 0, time() - (int) ( $job['started'] ?? time() ) );
	$tau     = 'lxc' === ( $job['type'] ?? '' ) ? 20 : ( ! empty( $job['post'] ) ? 60 : 6 );
	$timed   = 95 * ( 1 - exp( -$elapsed / $tau ) );
	$text    = 'Working…';
	$stage   = 0;
	$real    = null;

	$stages = array(
		'logical volume'                  => array( 10, 'Preparing storage' ),
		'creating filesystem'             => array( 25, 'Creating the filesystem' ),
		'extracting archive'              => array( 40, 'Unpacking the template' ),
		'total bytes read'                => array( 75, 'Template unpacked' ),
		'detected container architecture' => array( 85, 'Configuring the container' ),
		'ssh host key'                    => array( 92, 'Finishing setup' ),
		'create full clone'               => array( 3, 'Copying the disk' ),
	);

	foreach ( (array) $log as $line ) {
		$lower = strtolower( (string) $line );

		foreach ( $stages as $needle => $info ) {
			if ( strpos( $lower, $needle ) !== false ) {
				$stage = max( $stage, $info[0] );
				$text  = $info[1];
			}
		}

		if ( preg_match_all( '/(\d{1,3}(?:\.\d+)?)\s*%/', (string) $line, $m ) ) {
			$real = min( 99.0, (float) end( $m[1] ) );
			$text = 'Copying the disk (' . (int) round( $real ) . '%)';
		}
	}

	$pct = null !== $real ? $real : max( $timed, $stage );

	return array(
		'pct'  => min( 97, max( 2, $pct ) ),
		'text' => $text,
	);
}

/** After a clone finishes: CPU, memory, nesting, serial port (for the web shell) and optional start. Returns an error string or ''. */
function urzone_pve_finish_clone( $job ) {
	$base = urzone_pve_guest_path( $job['node'], 'qemu', $job['vmid'] );
	$post = (array) ( $job['post'] ?? array() );

	// "Template" button: the copy is finished, now turn it into a template.
	if ( ! empty( $post['template'] ) ) {
		$made = urzone_pve_post( $base . '/template' );

		if ( is_wp_error( $made ) ) {
			return 'The copy was made, but it could not be turned into a template: ' . $made->get_error_message();
		}

		urzone_pve_wait_task( $job['node'], (string) ( $made['data'] ?? '' ), 20 );

		return '';
	}

	$new  = array(
		'cores'  => (int) ( $post['cores'] ?? 2 ),
		'memory' => (int) ( $post['memory'] ?? 2048 ),
	);

	if ( ! empty( $post['nesting'] ) ) {
		$new['cpu'] = 'host';
	}

	$existing = urzone_pve_get( $base . '/config' );
	$has_ser  = false;

	if ( ! is_wp_error( $existing ) ) {
		foreach ( array( 'serial0', 'serial1', 'serial2', 'serial3' ) as $key ) {
			if ( isset( $existing['data'][ $key ] ) ) {
				$has_ser = true;
			}
		}
	}

	if ( ! $has_ser ) {
		$new['serial0'] = 'socket';
	}

	$config = urzone_pve_post( $base . '/config', $new );

	if ( is_wp_error( $config ) ) {
		return 'The VM was cloned, but its settings could not be applied: ' . $config->get_error_message();
	}

	if ( ! empty( $post['start'] ) ) {
		$started = urzone_pve_post( $base . '/status/start' );

		if ( is_wp_error( $started ) && stripos( $started->get_error_message(), 'already running' ) === false ) {
			return 'The VM was cloned, but it could not be started: ' . $started->get_error_message();
		}
	}

	return '';
}

/** Current state of one job: running | done | failed. May update the job (error / post_done). */
function urzone_pve_job_status( $upid, &$job ) {
	if ( ! empty( $job['error'] ) ) {
		return array( 'state' => 'failed', 'pct' => 100, 'text' => '', 'error' => (string) $job['error'] );
	}

	$node   = (string) ( $job['node'] ?? '' );
	$status = urzone_pve_get( '/nodes/' . rawurlencode( $node ) . '/tasks/' . rawurlencode( $upid ) . '/status' );

	if ( is_wp_error( $status ) ) {
		if ( time() - (int) ( $job['started'] ?? 0 ) > 1800 ) {
			$job['error'] = 'Proxmox did not report back about this task.';

			return array( 'state' => 'failed', 'pct' => 100, 'text' => '', 'error' => $job['error'] );
		}

		$p = urzone_pve_job_progress( $job, array() );

		return array( 'state' => 'running', 'pct' => $p['pct'], 'text' => 'Waiting for Proxmox…', 'error' => '' );
	}

	$data = (array) ( $status['data'] ?? array() );

	if ( 'running' === ( $data['status'] ?? '' ) ) {
		$p = urzone_pve_job_progress( $job, urzone_pve_task_log_tail( $node, $upid ) );

		return array( 'state' => 'running', 'pct' => $p['pct'], 'text' => $p['text'], 'error' => '' );
	}

	$exit = (string) ( $data['exitstatus'] ?? '' );

	if ( 'OK' !== $exit && 0 !== strpos( $exit, 'WARNINGS' ) ) {
		$job['error'] = sanitize_text_field( mb_substr( $exit !== '' ? $exit : 'The task failed.', 0, 200 ) );

		return array( 'state' => 'failed', 'pct' => 100, 'text' => '', 'error' => $job['error'] );
	}

	if ( ! empty( $job['post'] ) && empty( $job['post_done'] ) ) {
		$lock = 'uzpve_post_' . urzone_pve_job_id( $upid );

		if ( get_transient( $lock ) ) {
			return array( 'state' => 'running', 'pct' => 97, 'text' => 'Finishing setup', 'error' => '' );
		}

		set_transient( $lock, 1, 60 );
		$job['post_done'] = true;
		$error            = urzone_pve_finish_clone( $job );

		if ( $error !== '' ) {
			$job['error'] = $error;

			return array( 'state' => 'failed', 'pct' => 100, 'text' => '', 'error' => $error );
		}
	}

	urzone_pve_forget_owner( $node, (string) ( $job['type'] ?? '' ), (int) ( $job['vmid'] ?? 0 ) );
	delete_transient( 'uzpve_c_' . md5( '/nodes/' . rawurlencode( $node ) . '/qemu' ) );
	delete_transient( 'uzpve_c_' . md5( '/cluster/resources' ) );

	return array( 'state' => 'done', 'pct' => 100, 'text' => 'Ready', 'error' => '' );
}

function urzone_pve_jobs_route( WP_REST_Request $request ) {
	$jobs = urzone_pve_jobs_get();
	$out  = array();

	foreach ( $jobs as $upid => $job ) {
		$res           = urzone_pve_job_status( $upid, $job );
		$jobs[ $upid ] = $job;

		if ( 'done' === $res['state'] ) {
			unset( $jobs[ $upid ] ); // Reported once; the page reloads and shows the new instance.
		}

		$out[] = array(
			'id'    => urzone_pve_job_id( $upid ),
			'state' => $res['state'],
			'pct'   => (float) $res['pct'],
			'text'  => (string) $res['text'],
			'error' => (string) $res['error'],
		);
	}

	urzone_pve_jobs_save( $jobs );

	return rest_ensure_response( array( 'jobs' => $out ) );
}

function urzone_pve_jobs_dismiss_route( WP_REST_Request $request ) {
	$id   = sanitize_key( (string) $request->get_param( 'id' ) );
	$jobs = urzone_pve_jobs_get();

	foreach ( array_keys( $jobs ) as $upid ) {
		if ( urzone_pve_job_id( $upid ) === $id ) {
			unset( $jobs[ $upid ] );
		}
	}

	urzone_pve_jobs_save( $jobs );

	return rest_ensure_response( array( 'ok' => true ) );
}

function urzone_pve_register_job_routes() {
	register_rest_route(
		'urzone-pve/v1',
		'/jobs',
		array(
			'methods'             => 'GET',
			'callback'            => 'urzone_pve_jobs_route',
			'permission_callback' => 'urzone_pve_rest_permission',
		)
	);

	register_rest_route(
		'urzone-pve/v1',
		'/jobs/dismiss',
		array(
			'methods'             => 'POST',
			'callback'            => 'urzone_pve_jobs_dismiss_route',
			'permission_callback' => 'urzone_pve_rest_permission',
		)
	);
}

add_action( 'rest_api_init', 'urzone_pve_register_job_routes' );

/*
|--------------------------------------------------------------------------
| REST routes
|--------------------------------------------------------------------------
*/

function urzone_pve_rest_permission() {
	return is_user_logged_in();
}

/** Live overview: every visible guest + host I/O delay in a single request. */
function urzone_pve_overview_route( WP_REST_Request $request ) {
	$node = sanitize_text_field( (string) ( $request->get_param( 'node' ) ?: URZONE_PROXMOX_DEFAULT_NODE ) );

	if ( ! urzone_pve_valid_node( $node ) ) {
		return new WP_Error( 'urzone_pve_invalid_node', 'Invalid node.', array( 'status' => 400 ) );
	}

	// "scope=all" only widens the result for full-access users; anyone else always gets their own.
	$scope  = sanitize_key( (string) $request->get_param( 'scope' ) );
	$all    = urzone_pve_is_admin() && 'all' === $scope;

	if ( 'demo' === $scope ) {
		urzone_pve_demo_cleanup();
	}

	$guests = urzone_pve_owned_guests( $node, $all, 'demo' === $scope ? 'demo' : 'plan' );

	if ( is_wp_error( $guests ) ) {
		return new WP_Error( 'urzone_pve_overview_error', $guests->get_error_message(), array( 'status' => 502 ) );
	}

	$out = array();

	foreach ( $guests as $guest ) {
		$type   = (string) $guest['type'];
		$vmid   = absint( $guest['vmid'] );
		$status = (string) ( $guest['status'] ?? 'unknown' );

		$out[] = array(
			'vmid'      => $vmid,
			'type'      => $type,
			'name'      => (string) ( $guest['name'] ?? '' ),
			'status'    => $status,
			'uptime'    => (int) ( $guest['uptime'] ?? 0 ),
			'cpu'       => (float) ( $guest['cpu'] ?? 0 ),
			'mem'       => (float) ( $guest['mem'] ?? 0 ),
			'maxmem'    => (float) ( $guest['maxmem'] ?? 0 ),
			'netin'     => (float) ( $guest['netin'] ?? 0 ),
			'netout'    => (float) ( $guest['netout'] ?? 0 ),
			'diskread'  => (float) ( $guest['diskread'] ?? 0 ),
			'diskwrite' => (float) ( $guest['diskwrite'] ?? 0 ),
			'ip'        => urzone_pve_guest_ip( $node, $type, $vmid, $status ),
		);
	}

	$host   = urzone_pve_get_cached( '/nodes/' . rawurlencode( $node ) . '/status', 3 );
	$iowait = is_wp_error( $host ) ? 0 : (float) ( $host['data']['wait'] ?? 0 );

	return rest_ensure_response(
		array(
			'ts'     => microtime( true ),
			'guests' => $out,
			'host'   => array( 'iowait' => $iowait ),
		)
	);
}

/** Historical RRD data for one guest, with the host's I/O delay merged in. */
function urzone_pve_metrics_route( WP_REST_Request $request ) {
	$node      = sanitize_text_field( $request['node'] );
	$type      = sanitize_key( $request['type'] );
	$vmid      = absint( $request['vmid'] );
	$timeframe = sanitize_key( $request->get_param( 'timeframe' ) ?: 'hour' );

	if ( ! urzone_pve_valid_node( $node ) || ! in_array( $type, array( 'lxc', 'qemu' ), true ) || $vmid < 100 ) {
		return new WP_Error( 'urzone_pve_invalid_metrics_request', 'Invalid instance request.', array( 'status' => 400 ) );
	}

	if ( ! in_array( $timeframe, array( 'hour', 'day', 'week', 'month', 'year' ), true ) ) {
		$timeframe = 'hour';
	}

	if ( ! urzone_pve_can_manage_guest( $node, $type, $vmid ) ) {
		return new WP_Error( 'urzone_pve_not_owner', 'You do not own that instance.', array( 'status' => 403 ) );
	}

	$result = urzone_pve_get_cached(
		urzone_pve_guest_path( $node, $type, $vmid ) . '/rrddata?timeframe=' . rawurlencode( $timeframe ),
		15
	);

	if ( is_wp_error( $result ) ) {
		return new WP_Error( 'urzone_pve_metrics_error', $result->get_error_message(), array( 'status' => 502 ) );
	}

	$host_rrd = urzone_pve_get_cached(
		'/nodes/' . rawurlencode( $node ) . '/rrddata?timeframe=' . rawurlencode( $timeframe ),
		30
	);

	$iowait = array();

	if ( ! is_wp_error( $host_rrd ) ) {
		foreach ( (array) ( $host_rrd['data'] ?? array() ) as $row ) {
			if ( isset( $row['time'] ) ) {
				$iowait[ $row['time'] ] = (float) ( $row['iowait'] ?? 0 );
			}
		}
	}

	$rows = (array) ( $result['data'] ?? array() );

	foreach ( $rows as $index => $row ) {
		$rows[ $index ]['host_iowait'] = $iowait[ $row['time'] ?? 0 ] ?? 0;
	}

	return rest_ensure_response( array( 'data' => $rows ) );
}

/** First serial port of type "socket" in a VM config, or ''. Sets $other when a non-socket serial port exists. */
function urzone_pve_find_serial( $data, &$other = false ) {
	foreach ( array( 'serial0', 'serial1', 'serial2', 'serial3' ) as $key ) {
		if ( ! isset( $data[ $key ] ) ) {
			continue;
		}

		if ( strpos( (string) $data[ $key ], 'socket' ) === 0 ) {
			return $key;
		}

		$other = true;
	}

	return '';
}

/**
 * Shell: verifies ownership server-side, then returns a short-lived, single-use,
 * HMAC-signed websocket URL for the bridge. The bridge holds the Proxmox
 * credentials; the browser never sees them.
 *
 * Containers open directly. A VM needs a serial port (serial0 = socket) and a login
 * prompt on that port inside the guest. If the VM has no serial port yet, one is added
 * here and takes effect after the VM restarts.
 */
function urzone_pve_terminal_route( WP_REST_Request $request ) {
	if ( ! urzone_pve_terminal_configured() ) {
		return new WP_Error( 'urzone_pve_terminal_off', 'The web shell is not configured (URZONE_TERMINAL_URL / URZONE_TERMINAL_SECRET).', array( 'status' => 503 ) );
	}

	$node = sanitize_text_field( (string) $request['node'] );
	$type = sanitize_key( (string) ( $request['type'] ?: 'lxc' ) );
	$vmid = absint( $request['vmid'] );

	if ( ! urzone_pve_valid_node( $node ) || ! in_array( $type, array( 'lxc', 'qemu' ), true ) || $vmid < 100 ) {
		return new WP_Error( 'urzone_pve_bad_request', 'Invalid request.', array( 'status' => 400 ) );
	}

	if ( ! urzone_pve_can_manage_guest( $node, $type, $vmid ) ) {
		return new WP_Error( 'urzone_pve_not_owner', 'You do not own that instance.', array( 'status' => 403 ) );
	}

	$base   = urzone_pve_guest_path( $node, $type, $vmid );
	$status = urzone_pve_get( $base . '/status/current' );

	if ( is_wp_error( $status ) ) {
		return new WP_Error( 'urzone_pve_terminal_status', $status->get_error_message(), array( 'status' => 502 ) );
	}

	if ( ( $status['data']['status'] ?? '' ) !== 'running' ) {
		return new WP_Error( 'urzone_pve_not_running', 'Start the instance before opening a shell.', array( 'status' => 409 ) );
	}

	$serial = '';

	if ( 'qemu' === $type ) {
		// current=1: what the RUNNING VM has. Without it Proxmox also returns changes that are still pending a restart.
		$running = urzone_pve_get( $base . '/config?current=1' );

		if ( is_wp_error( $running ) ) {
			return new WP_Error( 'urzone_pve_terminal_config', $running->get_error_message(), array( 'status' => 502 ) );
		}

		$other  = false;
		$serial = urzone_pve_find_serial( (array) ( $running['data'] ?? array() ), $other );

		if ( $serial === '' ) {
			if ( $other ) {
				return new WP_Error( 'urzone_pve_no_socket', 'This VM has a serial port that is not a socket, so the web shell cannot use it.', array( 'status' => 409 ) );
			}

			$pending = urzone_pve_get( $base . '/config' ); // includes pending changes

			if ( ! is_wp_error( $pending ) && urzone_pve_find_serial( (array) ( $pending['data'] ?? array() ) ) !== '' ) {
				return new WP_Error(
					'urzone_pve_serial_pending',
					'This VM has a serial port, but it is not active yet. Click Restart on the card (or use Stop, then Start), then open the shell again.',
					array( 'status' => 409 )
				);
			}

			// No serial port at all: add one. It becomes active after the VM restarts.
			$added = urzone_pve_post( $base . '/config', array( 'serial0' => 'socket' ) );

			if ( is_wp_error( $added ) ) {
				return new WP_Error( 'urzone_pve_serial_failed', $added->get_error_message(), array( 'status' => 502 ) );
			}

			return new WP_Error(
				'urzone_pve_serial_added',
				'A serial port was added to this VM. Click Restart on the card, then open the shell again. The VM also needs a login prompt on its serial port (ttyS0); most cloud images already have one.',
				array( 'status' => 409 )
			);
		}
	}

	$claims = array(
		'n'   => $node,
		't'   => $type,
		'v'   => $vmid,
		'u'   => get_current_user_id(),
		'exp' => time() + 30,
		'jti' => wp_generate_password( 16, false ),
	);

	if ( $serial !== '' ) {
		$claims['s'] = $serial;
	}

	$payload = rtrim( strtr( base64_encode( wp_json_encode( $claims ) ), '+/', '-_' ), '=' );
	$sig     = hash_hmac( 'sha256', $payload, URZONE_TERMINAL_SECRET );

	return rest_ensure_response(
		array( 'url' => trim( (string) URZONE_TERMINAL_URL ) . '?t=' . $payload . '.' . $sig )
	);
}

function urzone_pve_register_routes() {
	register_rest_route(
		'urzone-pve/v1',
		'/overview',
		array(
			'methods'             => 'GET',
			'callback'            => 'urzone_pve_overview_route',
			'permission_callback' => 'urzone_pve_rest_permission',
		)
	);

	register_rest_route(
		'urzone-pve/v1',
		'/metrics/(?P<node>[A-Za-z0-9._-]+)/(?P<type>lxc|qemu)/(?P<vmid>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'urzone_pve_metrics_route',
			'permission_callback' => 'urzone_pve_rest_permission',
		)
	);

	register_rest_route(
		'urzone-pve/v1',
		'/terminal/(?P<node>[A-Za-z0-9._-]+)/(?:(?P<type>lxc|qemu)/)?(?P<vmid>\d+)',
		array(
			'methods'             => 'POST',
			'callback'            => 'urzone_pve_terminal_route',
			'permission_callback' => 'urzone_pve_rest_permission',
		)
	);
}

add_action( 'rest_api_init', 'urzone_pve_register_routes' );

/*
|--------------------------------------------------------------------------
| View helpers
|--------------------------------------------------------------------------
*/

function urzone_pve_bytes( $bytes ) {
	$bytes = (float) $bytes;

	if ( $bytes <= 0 ) {
		return '—';
	}

	$units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
	$index = 0;

	while ( $bytes >= 1024 && $index < count( $units ) - 1 ) {
		$bytes /= 1024;
		$index++;
	}

	return number_format_i18n( $bytes, $index ? 1 : 0 ) . ' ' . $units[ $index ];
}

function urzone_pve_render_card( $guest, $node, $nonce ) {
	$type   = (string) ( $guest['type'] ?? '' );
	$vmid   = absint( $guest['vmid'] ?? 0 );
	$status = (string) ( $guest['status'] ?? 'unknown' );
	$name   = (string) ( $guest['name'] ?? ( 'VMID ' . $vmid ) );
	$run    = $status === 'running';

	$show_shell = urzone_pve_terminal_configured(); // containers and VMs

	$tiles = array(
		'cpu'  => 'CPU',
		'mem'  => 'Memory',
		'net'  => 'Network',
		'disk' => 'Disk I/O',
		'io'   => 'Host I/O delay',
	);

	ob_start();
	?>
	<article class="uzp-vm" data-card="<?php echo esc_attr( $vmid ); ?>" data-status="<?php echo esc_attr( $status ); ?>">
		<header class="uzp-vm-head">
			<div>
				<h4 class="uzp-vm-name"><?php echo esc_html( $name ); ?></h4>
				<div class="uzp-vm-meta">
					<span class="uzp-chip"><?php echo esc_html( strtoupper( $type ) ); ?></span>
					<span class="uzp-chip">VMID <?php echo esc_html( $vmid ); ?></span>
					<span class="uzp-chip">IP <b data-ip>…</b></span>
				</div>
			</div>
			<span class="uzp-badge" data-badge><?php echo esc_html( $status ); ?></span>
		</header>

		<div class="uzp-vm-facts">
			<span>Uptime <b data-uptime>—</b></span>
			<span>RAM <b data-ram><?php echo esc_html( urzone_pve_bytes( $guest['mem'] ?? 0 ) . ' / ' . urzone_pve_bytes( $guest['maxmem'] ?? 0 ) ); ?></b></span>
		</div>

		<div class="uzp-tiles">
			<?php foreach ( $tiles as $key => $label ) : ?>
				<div class="uzp-tile" data-tile="<?php echo esc_attr( $key ); ?>">
					<div class="uzp-tile-h"><span><?php echo esc_html( $label ); ?></span><b data-val>—</b></div>
					<svg viewBox="0 0 300 64" preserveAspectRatio="none" aria-hidden="true"></svg>
				</div>
			<?php endforeach; ?>
		</div>

		<form method="post" class="uzp-actions">
			<input type="hidden" name="urzone_pve_nonce" value="<?php echo esc_attr( $nonce ); ?>">
			<input type="hidden" name="node" value="<?php echo esc_attr( $node ); ?>">
			<input type="hidden" name="guest_type" value="<?php echo esc_attr( $type ); ?>">
			<input type="hidden" name="vmid" value="<?php echo esc_attr( $vmid ); ?>">
			<input type="hidden" name="uzp_return" value="<?php echo esc_url( urzone_pve_return_url() ); ?>">

			<button name="urzone_pve_action" value="start" class="uzp-btn uzp-go" data-need="stopped" <?php disabled( $run ); ?>>Start</button>

			<?php if ( $show_shell ) : ?>
				<button type="button" class="uzp-btn uzp-term-btn" data-need="running" data-terminal
					data-node="<?php echo esc_attr( $node ); ?>"
					data-type="<?php echo esc_attr( $type ); ?>"
					data-vmid="<?php echo esc_attr( $vmid ); ?>"
					data-name="<?php echo esc_attr( $name ); ?>"
					title="<?php echo $type === 'qemu' ? 'Serial console. The VM needs a serial port and a login prompt on it.' : 'Open a shell'; ?>" <?php disabled( ! $run ); ?>>Shell</button>
			<?php endif; ?>

			<button name="urzone_pve_action" value="shutdown" class="uzp-btn" data-need="running" <?php disabled( ! $run ); ?>
				data-confirm="Gracefully stop “<?php echo esc_attr( $name ); ?>” (VMID <?php echo esc_attr( $vmid ); ?>)? It is forced off after 30 seconds if it does not shut down.">Stop</button>
			<button name="urzone_pve_action" value="reboot" class="uzp-btn" data-need="running" <?php disabled( ! $run ); ?>
				data-confirm="Restart “<?php echo esc_attr( $name ); ?>”?">Restart</button>
			<button name="urzone_pve_action" value="stop" class="uzp-btn uzp-warn" data-need="running" <?php disabled( ! $run ); ?>
				data-confirm="FORCE stop VMID <?php echo esc_attr( $vmid ); ?>? This is like pulling the power cable and can lose unsaved data.">Force stop</button>
			<button name="urzone_pve_action" value="delete" class="uzp-btn uzp-danger" data-need="stopped" <?php disabled( $run ); ?>
				data-confirm="Permanently delete “<?php echo esc_attr( $name ); ?>” and all of its disks? This cannot be undone."
				data-type-confirm="<?php echo esc_attr( $vmid ); ?>">Delete</button>
		</form>

		<details class="uzp-history" data-history data-node="<?php echo esc_attr( $node ); ?>" data-type="<?php echo esc_attr( $type ); ?>" data-vmid="<?php echo esc_attr( $vmid ); ?>">
			<summary>History</summary>
			<select class="uzp-timeframe" data-timeframe aria-label="History timeframe">
				<option value="hour">Last hour</option>
				<option value="day">Last day</option>
				<option value="week">Last week</option>
				<option value="month">Last month</option>
				<option value="year">Last year</option>
			</select>
			<div class="uzp-hist-grid" data-hist></div>
		</details>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Super-admin diagnostics (add ?uzpve_debug=1 to the page address): shows, for every guest on the node,
 * what Proxmox says its owner is and whether it is listed for you, and why not.
 */
function urzone_pve_debug_panel( $node, $plan ) {
	$resources = urzone_pve_get( '/cluster/resources' );
	$uid       = get_current_user_id();
	$is_admin  = ! empty( $plan['admin'] );
	$is_demo   = ! empty( $plan['demo'] );

	ob_start();
	echo '<div class="uzp-notice uzp-info" style="overflow:auto"><strong>urZONE PVE debug</strong> · you are WordPress user #' . esc_html( $uid ) . ' · view: ' . esc_html( $plan['key'] ) . ' · site: #' . esc_html( get_current_blog_id() ) . '<br>';

	if ( is_wp_error( $resources ) ) {
		echo 'Proxmox error: ' . esc_html( $resources->get_error_message() ) . '</div>';
		return ob_get_clean();
	}

	echo '<table style="width:100%;border-collapse:collapse;margin-top:8px;font-size:12px"><tr style="text-align:left"><th>VMID</th><th>Type</th><th>Name</th><th>Status</th><th>Owner in Proxmox</th><th>Demo</th><th>Listed here?</th><th>Description (start)</th></tr>';

	foreach ( (array) ( $resources['data'] ?? array() ) as $r ) {
		if ( ! is_array( $r ) || ! in_array( $r['type'] ?? '', array( 'lxc', 'qemu' ), true ) || ( $r['node'] ?? '' ) !== $node || ! empty( $r['template'] ) ) {
			continue;
		}

		$vmid   = absint( $r['vmid'] ?? 0 );
		$config = urzone_pve_get( urzone_pve_guest_path( $node, $r['type'], $vmid ) . '/config' ); // fresh, not cached
		$desc   = is_wp_error( $config ) ? '' : (string) ( $config['data']['description'] ?? '' );
		$owner  = urzone_pve_parse_owner( $desc );
		$demo   = urzone_pve_parse_demo( $desc );

		if ( is_wp_error( $config ) ) {
			$why = 'unknown: could not read its config (' . $config->get_error_message() . ')';
		} elseif ( $is_admin ) {
			$why = 'yes (admin view lists everything)';
		} elseif ( $owner === 0 ) {
			$why = 'NO: no owner marker in its description';
		} elseif ( $owner !== $uid ) {
			$why = 'NO: owned by user #' . $owner . ', you are #' . $uid;
		} elseif ( $demo > 0 && ! $is_demo ) {
			$why = 'NO: it is a demo instance (listed on the demo page only)';
		} elseif ( 0 === $demo && $is_demo ) {
			$why = 'NO: not a demo instance';
		} else {
			$why = 'yes';
		}

		echo '<tr style="border-top:1px solid #2f5273"><td>' . esc_html( $vmid ) . '</td><td>' . esc_html( $r['type'] ) . '</td><td>' . esc_html( (string) ( $r['name'] ?? '' ) ) . '</td><td>' . esc_html( (string) ( $r['status'] ?? '' ) ) . '</td><td>' . ( $owner ? '#' . esc_html( $owner ) : '—' ) . '</td><td>' . ( $demo ? 'yes' : 'no' ) . '</td><td>' . esc_html( $why ) . '</td><td>' . esc_html( str_replace( "\n", ' / ', mb_substr( $desc, 0, 100 ) ) ) . '</td></tr>';
	}

	echo '</table></div>';

	return ob_get_clean();
}

/** One compact row for the "Layer" view, with a View button on the right. */
function urzone_pve_render_row( $guest, $features = array() ) {
	$type   = (string) ( $guest['type'] ?? '' );
	$vmid   = absint( $guest['vmid'] ?? 0 );
	$status = (string) ( $guest['status'] ?? 'unknown' );
	$name   = (string) ( $guest['name'] ?? ( 'VMID ' . $vmid ) );

	ob_start();
	?>
	<div class="uzp-row" data-row="<?php echo esc_attr( $vmid ); ?>" data-status="<?php echo esc_attr( $status ); ?>">
		<div class="uzp-row-name">
			<b><?php echo esc_html( $name ); ?></b>
			<span class="uzp-chip"><?php echo esc_html( strtoupper( $type ) ); ?></span>
			<span class="uzp-chip">VMID <?php echo esc_html( $vmid ); ?></span>
		</div>
		<span class="uzp-badge" data-r-badge><?php echo esc_html( $status ); ?></span>
		<div class="uzp-row-cell"><small>IP</small><b data-r-ip>…</b></div>
		<div class="uzp-row-cell"><small>CPU</small><b data-r-cpu>—</b></div>
		<div class="uzp-row-cell"><small>Memory</small><b data-r-mem>—</b></div>
		<div class="uzp-row-cell"><small>Uptime</small><b data-r-up>—</b></div>
		<div class="uzp-row-btns">
			<?php foreach ( array( 'snapshot' => 'Snapshot', 'clone' => 'Clone', 'template' => 'Template' ) as $feature => $label ) : ?>
				<?php
				if ( ! in_array( $feature, (array) $features, true ) || ( 'template' === $feature && 'qemu' !== $type ) ) {
					continue;
				}
				?>
				<button type="button" class="uzp-btn" data-act="<?php echo esc_attr( $feature ); ?>"
					data-vmid="<?php echo esc_attr( $vmid ); ?>"
					data-type="<?php echo esc_attr( $type ); ?>"
					data-name="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></button>
			<?php endforeach; ?>
			<button type="button" class="uzp-btn uzp-row-view" data-open="<?php echo esc_attr( $vmid ); ?>">View</button>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function urzone_pve_admin_fields( $plan, $with_bridge = true ) {
	if ( empty( $plan['admin'] ) ) {
		return '';
	}

	$html  = '<label>VMID <input type="number" name="vmid" min="100" placeholder="Automatic"></label>';
	$html .= '<label>Storage <input type="text" name="storage" value="' . esc_attr( URZONE_PROXMOX_DEFAULT_STORAGE ) . '" required></label>';

	if ( $with_bridge ) {
		$html .= '<label>Network Bridge <input type="text" name="bridge" value="' . esc_attr( URZONE_PROXMOX_DEFAULT_BRIDGE ) . '" required></label>';
	}

	return $html;
}

function urzone_pve_start_checkbox( $checked = true ) {
	return '<p><label class="uzp-check"><input type="checkbox" name="start" value="1"' . ( $checked ? ' checked' : '' ) . '> Start after creation</label></p>';
}

/** Pre-checked nesting option for VMs (uses the host CPU type so the VM can run its own KVM). */
function urzone_pve_vm_nesting_checkbox() {
	return '<p><label class="uzp-check"><input type="checkbox" name="nesting" value="1" checked style="width:auto;margin:0;"> Enable nesting (lets this VM run its own virtual machines; uses the host CPU type)</label></p>';
}

/** The address of the page the panel is on, so an action sends the user back to it (not to the front page). */
function urzone_pve_return_url() {
	global $wp;

	$url = '';

	if ( is_singular() && get_queried_object_id() ) {
		$url = (string) get_permalink( get_queried_object_id() );
	}

	if ( $url === '' ) {
		$url = home_url( isset( $wp->request ) ? $wp->request : '' );
	}

	return $url;
}

function urzone_pve_form_open( $action, $node, $nonce, $plan ) {
	return '<form method="post">' .
		'<input type="hidden" name="urzone_pve_nonce" value="' . esc_attr( $nonce ) . '">' .
		'<input type="hidden" name="urzone_pve_action" value="' . esc_attr( $action ) . '">' .
		'<input type="hidden" name="node" value="' . esc_attr( $node ) . '">' .
		'<input type="hidden" name="uzp_plan" value="' . esc_attr( $plan['key'] ) . '">' .
		'<input type="hidden" name="uzp_plan_sig" value="' . esc_attr( urzone_pve_plan_sig( $plan['key'] ) ) . '">' .
		'<input type="hidden" name="uzp_return" value="' . esc_url( urzone_pve_return_url() ) . '">';
}

function urzone_pve_css() {
	$css_file = plugin_dir_path( __FILE__ ) . 'assets/css/urzone-pve.css';
	if ( is_readable( $css_file ) ) {
		$css = file_get_contents( $css_file );
		if ( $css !== false && $css !== '' ) {
			return "<style id=\"urzone-pve-css\">\n" . $css . "\n</style>";
		}
	}
	// Fallback: minimal shell so the UI still appears if assets are missing.
	return '<style id="urzone-pve-css">.urzone-pve{max-width:1500px;margin:20px auto;color:#e2e8f0;font-family:system-ui,sans-serif}.urzone-pve .uzp-shell{background:#0d1117;border:1px solid #1e293b;border-radius:16px;overflow:hidden}</style>';
}


/** xterm.js from a pinned CDN version; printed once, only when the shell is configured. */
function urzone_pve_terminal_assets() {
	return '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/xterm@5.3.0/css/xterm.css">' .
		'<script src="https://cdn.jsdelivr.net/npm/xterm@5.3.0/lib/xterm.js"></script>' .
		'<script src="https://cdn.jsdelivr.net/npm/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.js"></script>';
}

function urzone_pve_js() {
	$js_file = plugin_dir_path( __FILE__ ) . 'assets/js/urzone-pve.js';
	if ( is_readable( $js_file ) ) {
		$js = file_get_contents( $js_file );
		if ( $js !== false && $js !== '' ) {
			return "<script id=\"urzone-pve-js\">\n" . $js . "\n</script>";
		}
	}
	return '<!-- urZONE PVE: assets/js/urzone-pve.js missing -->';
}


function urzone_pve_render( $atts, $plan_key, $tag ) {
	static $assets_printed = false;
	static $instance       = 0;

	if ( ! is_user_logged_in() ) {
		return '<p>You must be logged in to access urZONE PVE.</p>';
	}

	$plan = urzone_pve_get_plan( $plan_key );

	if ( ! $plan ) {
		return urzone_pve_denied_message( $plan_key );
	}

	$atts = shortcode_atts( array( 'node' => URZONE_PROXMOX_DEFAULT_NODE ), $atts, $tag );
	$node = sanitize_text_field( $atts['node'] );

	if ( ! urzone_pve_valid_node( $node ) ) {
		return '<p>Invalid Proxmox node.</p>';
	}

	if ( ! urzone_pve_configured() ) {
		return '<p>urZONE PVE is not configured yet.</p>';
	}

	$instance++;
	$uid      = 'uzp' . $instance;
	$is_admin = ! empty( $plan['admin'] );
	$limit    = urzone_pve_plan_limit( $plan );

	$is_demo = ! empty( $plan['demo'] );
	$caps    = urzone_pve_caps( $plan );
	$demo    = $is_demo ? urzone_pve_demo_state() : null;

	if ( $is_demo ) {
		urzone_pve_demo_cleanup(); // Cheap no-op unless something has expired.
	}

	$guests_result = urzone_pve_owned_guests( $node, $is_admin, $is_demo ? 'demo' : ( $is_admin ? 'any' : 'plan' ) );
	$guests        = is_wp_error( $guests_result ) ? array() : $guests_result;

	// Instances still being created are shown as progress bars, not cards, until they are ready.
	$jobs        = array();
	$pending_ids = array();

	foreach ( urzone_pve_jobs_get() as $upid => $job ) {
		if ( ( $job['node'] ?? '' ) !== $node ) {
			continue;
		}

		$jobs[ $upid ] = $job;

		if ( empty( $job['error'] ) ) {
			$pending_ids[] = absint( $job['vmid'] );
		}
	}

	$guests   = array_values(
		array_filter(
			$guests,
			static function ( $guest ) use ( $pending_ids ) {
				return ! in_array( absint( $guest['vmid'] ?? 0 ), $pending_ids, true );
			}
		)
	);
	$at_limit = $limit > 0 && ( count( $guests ) + count( $pending_ids ) ) >= $limit;

	$lxc_result = urzone_pve_get_cached(
		'/nodes/' . rawurlencode( $node ) . '/storage/' . rawurlencode( URZONE_PROXMOX_TEMPLATE_STORAGE ) . '/content?content=vztmpl',
		30
	);
	$iso_result = urzone_pve_get_cached(
		'/nodes/' . rawurlencode( $node ) . '/storage/' . rawurlencode( URZONE_PROXMOX_ISO_STORAGE ) . '/content?content=iso',
		30
	);

	$lxc_templates = is_wp_error( $lxc_result ) ? array() : (array) ( $lxc_result['data'] ?? array() );
	$iso_images    = is_wp_error( $iso_result ) ? array() : (array) ( $iso_result['data'] ?? array() );
	$vm_templates  = urzone_pve_vm_templates( $node );

	$notice_key = 'uzpve_notice_' . get_current_user_id();
	$notice     = get_transient( $notice_key );

	if ( is_array( $notice ) ) {
		delete_transient( $notice_key );
	}

	$term_ok  = urzone_pve_terminal_configured();
	$features = urzone_pve_plan_features( $plan );
	$nonce   = wp_create_nonce( 'urzone_pve_action' );
	$running = count(
		array_filter(
			$guests,
			static function ( $guest ) {
				return ( $guest['status'] ?? '' ) === 'running';
			}
		)
	);

	ob_start();

	if ( ! $assets_printed ) {
		echo urzone_pve_css(); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $term_ok ) {
			echo urzone_pve_terminal_assets(); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		$assets_printed = true;
		$print_js       = true;
	} else {
		$print_js = false;
	}
	?>
	<div class="urzone-pve"
		data-uid="<?php echo esc_attr( $uid ); ?>"
		data-mode="grid"
		data-scope="<?php echo $is_demo ? 'demo' : ( $is_admin ? 'all' : 'own' ); ?>"
		data-overview="<?php echo esc_url( rest_url( 'urzone-pve/v1/overview' ) ); ?>"
		data-metrics="<?php echo esc_url( rest_url( 'urzone-pve/v1/metrics/' ) ); ?>"
		data-terminal="<?php echo $term_ok ? esc_url( rest_url( 'urzone-pve/v1/terminal/' ) ) : ''; ?>"
		data-jobs="<?php echo esc_url( rest_url( 'urzone-pve/v1/jobs' ) ); ?>"
		data-pending="<?php echo esc_attr( implode( ',', $pending_ids ) ); ?>"
		data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
		data-node="<?php echo esc_attr( $node ); ?>"
		data-interval="<?php echo esc_attr( max( 3, (int) URZONE_PROXMOX_POLL_SECONDS ) ); ?>"
		data-anonce="<?php echo esc_attr( $nonce ); ?>"
		data-return-url="<?php echo esc_url( urzone_pve_return_url() ); ?>"
		data-plan="<?php echo esc_attr( $plan['key'] ); ?>"
		data-plansig="<?php echo esc_attr( urzone_pve_plan_sig( $plan['key'] ) ); ?>">
		<div class="uzp-shell">
			<div class="uzp-head">
				<div>
					<h2>urZONE PVE <span class="uzp-plan"><?php echo esc_html( $plan['label'] ); ?></span></h2>
					<p>Your VMs and LXC containers · Node: <?php echo esc_html( $node ); ?></p>
				</div>
				<span class="uzp-head-status">
					<span class="uzp-live" data-live>Connecting…</span>
					<button type="button" class="uzp-theme-toggle" data-theme-toggle title="Toggle dark / light mode">
						<span data-theme-label>Dark</span>
					</button>
					<button type="button" class="uzp-refresh" data-refresh title="Reload the whole page">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>
						Refresh
					</button>
				</span>
			</div>

			<?php if ( is_array( $notice ) ) : ?>
				<div class="uzp-notice <?php echo $notice['type'] === 'error' ? 'uzp-error' : 'uzp-success'; ?>" role="status">
					<?php echo esc_html( $notice['message'] ); ?>
				</div>
			<?php endif; ?>

			<?php if ( is_wp_error( $guests_result ) ) : ?>
				<div class="uzp-notice uzp-error">
					<strong>Proxmox resource request failed:</strong>
					<?php echo esc_html( $guests_result->get_error_message() ); ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $jobs ) ) : ?>
				<div class="uzp-jobs" data-jobbox>
					<?php foreach ( $jobs as $upid => $job ) : ?>
						<div class="uzp-job" data-job="<?php echo esc_attr( urzone_pve_job_id( $upid ) ); ?>" data-state="<?php echo empty( $job['error'] ) ? 'running' : 'failed'; ?>">
							<div class="uzp-job-head">
								<b>Creating <?php echo ! empty( $job['post']['template'] ) ? 'template' : ( 'lxc' === $job['type'] ? 'container' : 'virtual machine' ); ?> “<?php echo esc_html( $job['name'] ); ?>” · VMID <?php echo esc_html( $job['vmid'] ); ?></b>
								<span data-job-pct>…</span>
							</div>
							<div class="uzp-bar"><div class="uzp-bar-fill" data-job-fill style="width:3%"></div></div>
							<div class="uzp-job-text" data-job-text>Starting…</div>
							<button type="button" class="uzp-btn" data-job-dismiss hidden>Dismiss</button>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( isset( $_GET['uzpve_debug'] ) && urzone_pve_is_admin() ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<?php echo urzone_pve_debug_panel( $node, $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endif; ?>

			<?php if ( $is_demo ) : ?>
				<div class="uzp-demo" data-demo
					data-end="<?php echo esc_attr( $demo['active'] ? $demo['end'] : 0 ); ?>"
					data-now="<?php echo esc_attr( $demo['now'] ); ?>"
					data-warn="<?php echo esc_attr( max( 0, (int) URZONE_PROXMOX_DEMO_WARN_MINUTES ) ); ?>">
					<b>Demo</b>
					<?php if ( $demo['active'] ) : ?>
						<span data-demo-text>Time remaining in your demo:</span>
						<span class="uzp-demo-clock" data-demo-clock>--:--</span>
						<span class="uzp-mini">Everything you create here is deleted automatically when time runs out.</span>
					<?php elseif ( ! $demo['can_start'] ) : ?>
						<span data-demo-text>Your demo has ended. Your next demo is available in <?php echo esc_html( max( 1, (int) ceil( ( $demo['next'] - $demo['now'] ) / 60 ) ) ); ?> minute(s).</span>
						<span class="uzp-demo-clock" data-demo-clock hidden></span>
					<?php else : ?>
						<span data-demo-text>
							<?php echo $demo['start'] > 0 ? 'Your last demo has ended. ' : ''; ?>
							Your <?php echo esc_html( (int) URZONE_PROXMOX_DEMO_MINUTES ); ?>-minute demo starts when you create your first instance. Everything you create is deleted automatically when it ends.
						</span>
						<span class="uzp-demo-clock" data-demo-clock hidden></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="uzp-grid">
				<div class="uzp-card">
					<div class="uzp-label"><?php echo $is_admin ? 'All Instances' : 'My Instances'; ?></div>
					<div class="uzp-value"><?php echo esc_html( count( $guests ) ); ?><?php echo $limit > 0 ? ' <small>/ ' . esc_html( $limit ) . '</small>' : ''; ?></div>
				</div>
				<div class="uzp-card"><div class="uzp-label">Running</div><div class="uzp-value uzp-online" data-sum-running><?php echo esc_html( $running ); ?></div></div>
				<div class="uzp-card"><div class="uzp-label">Stopped</div><div class="uzp-value uzp-offline" data-sum-stopped><?php echo esc_html( count( $guests ) - $running ); ?></div></div>
				<div class="uzp-card"><div class="uzp-label">Account</div><div class="uzp-value" style="font-size:18px;"><?php echo esc_html( wp_get_current_user()->user_login ); ?></div></div>
			</div>

			<div class="uzp-panel">
				<div class="uzp-panel-head">
					<h3><?php echo $is_admin ? 'All Containers and Virtual Machines' : 'My Containers and Virtual Machines'; ?></h3>
					<?php if ( ! empty( $guests ) ) : ?>
						<div class="uzp-seg" role="group" aria-label="View mode">
							<button type="button" class="active" data-setmode="grid">Grid</button>
							<button type="button" data-setmode="layer">Layer</button>
						</div>
					<?php endif; ?>
				</div>

				<?php if ( empty( $guests ) ) : ?>
					<p>You do not have any assigned instances yet. Create one below.</p>
				<?php else : ?>
					<div class="uzp-vms">
						<?php
						foreach ( $guests as $guest ) {
							echo urzone_pve_render_card( $guest, $node, $nonce ); // phpcs:ignore WordPress.Security.EscapeOutput
						}
						?>
					</div>
					<div class="uzp-list">
						<?php
						foreach ( $guests as $guest ) {
							echo urzone_pve_render_row( $guest, $features ); // phpcs:ignore WordPress.Security.EscapeOutput
						}
						?>
					</div>
				<?php endif; ?>
			</div>

			<div class="uzp-panel">
				<h3>Create New Instance</h3>

				<?php if ( $at_limit ) : ?>
					<div class="uzp-info">
						Your <?php echo esc_html( $plan['label'] ); ?> plan includes <?php echo esc_html( $limit ); ?> instance<?php echo $limit === 1 ? '' : 's'; ?>, and you are using all of them. Delete one to create another.
					</div>
				<?php else : ?>

				<div class="uzp-tabs">
					<button type="button" class="uzp-tab active" data-uzp-tab="lxc">LXC Container</button>
					<button type="button" class="uzp-tab" data-uzp-tab="vm-template">VM from Template</button>
					<button type="button" class="uzp-tab" data-uzp-tab="vm-iso">VM from ISO</button>
					<button type="button" class="uzp-tab" data-uzp-tab="vm-empty">Create Empty VM</button>
				</div>

				<div id="<?php echo esc_attr( $uid ); ?>-create-lxc" class="uzp-create-panel is-active">
					<?php if ( empty( $lxc_templates ) ) : ?>
						<p>No LXC templates are available in <code><?php echo esc_html( URZONE_PROXMOX_TEMPLATE_STORAGE ); ?>:vztmpl</code>.</p>
					<?php else : ?>
						<?php echo urzone_pve_form_open( 'create_lxc', $node, $nonce, $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<div class="uzp-form-grid">
								<?php echo urzone_pve_admin_fields( $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<label>Hostname <input type="text" name="hostname" pattern="[A-Za-z0-9][A-Za-z0-9.\-]*" maxlength="63" required></label>
								<label>Container Template
									<select name="template" required>
										<option value="">Select template</option>
										<?php foreach ( $lxc_templates as $template ) : ?>
											<?php $volid = (string) ( $template['volid'] ?? '' ); ?>
											<?php if ( strpos( $volid, URZONE_PROXMOX_TEMPLATE_STORAGE . ':vztmpl/' ) === 0 ) : ?>
												<option value="<?php echo esc_attr( $volid ); ?>"><?php echo esc_html( basename( $volid ) ); ?></option>
											<?php endif; ?>
										<?php endforeach; ?>
									</select>
								</label>
								<label>Disk Size (GB) <input type="number" name="disk_gb" min="1" max="<?php echo esc_attr( $caps['disk'] ); ?>" value="<?php echo esc_attr( min( 8, $caps['disk'] ) ); ?>" required></label>
								<label>CPU Cores <input type="number" name="cores" min="1" max="<?php echo esc_attr( $caps['cores'] ); ?>" value="1" required></label>
								<label>Memory (MB) <input type="number" name="memory" min="256" max="<?php echo esc_attr( $caps['memory'] ); ?>" value="<?php echo esc_attr( min( 1024, $caps['memory'] ) ); ?>" required></label>
								<label>Root Password (8+ characters) <input type="password" name="password" minlength="8" autocomplete="new-password" required></label>
								<label>SSH Public Keys <textarea name="ssh_keys" placeholder="Optional: ssh-ed25519 AAAA..."></textarea></label>
								<label>Description <textarea name="description" placeholder="Optional notes"></textarea></label>
							</div>
							<p><label class="uzp-check"><input type="checkbox" name="nesting" value="1" checked style="width:auto;margin:0;"> Enable nesting (needed to run Docker or other containers inside this LXC)</label></p>
							<?php echo urzone_pve_start_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<p><button type="submit" class="uzp-submit">Create My LXC Container</button></p>
						</form>
					<?php endif; ?>
				</div>

				<div id="<?php echo esc_attr( $uid ); ?>-create-vm-template" class="uzp-create-panel">
					<p class="uzp-mini">Best for fast Linux deployment. Use a template that already includes cloud-init for automatic first-boot configuration.</p>
					<?php if ( empty( $vm_templates ) ) : ?>
						<p>No Proxmox VM templates were found on this node.</p>
					<?php else : ?>
						<?php echo urzone_pve_form_open( 'clone_vm_template', $node, $nonce, $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<div class="uzp-form-grid">
								<?php echo urzone_pve_admin_fields( $plan, false ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<label>VM Template
									<select name="template_vmid" required>
										<option value="">Select VM template</option>
										<?php foreach ( $vm_templates as $template ) : ?>
											<option value="<?php echo esc_attr( absint( $template['vmid'] ?? 0 ) ); ?>">
												<?php echo esc_html( ( $template['name'] ?? 'VM Template' ) . ' (VMID ' . absint( $template['vmid'] ?? 0 ) . ')' ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</label>
								<label>VM Name <input type="text" name="name" pattern="[A-Za-z0-9][A-Za-z0-9.\-]*" maxlength="63" required></label>
								<label>CPU Cores <input type="number" name="cores" min="1" max="<?php echo esc_attr( $caps['cores'] ); ?>" value="<?php echo esc_attr( min( 2, $caps['cores'] ) ); ?>" required></label>
								<label>Memory (MB) <input type="number" name="memory" min="512" max="<?php echo esc_attr( $caps['memory'] ); ?>" value="<?php echo esc_attr( min( 2048, $caps['memory'] ) ); ?>" required></label>
								<label>Description <textarea name="description" placeholder="Optional notes"></textarea></label>
							</div>
							<?php echo urzone_pve_start_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<?php echo urzone_pve_vm_nesting_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<p><button type="submit" class="uzp-submit">Clone My Virtual Machine</button></p>
						</form>
					<?php endif; ?>
				</div>

				<div id="<?php echo esc_attr( $uid ); ?>-create-vm-iso" class="uzp-create-panel">
					<p class="uzp-mini">Use this for Windows, custom operating systems, or manual installation through the VM console.</p>
					<?php if ( empty( $iso_images ) ) : ?>
						<p>No ISO images are available in <code><?php echo esc_html( URZONE_PROXMOX_ISO_STORAGE ); ?>:iso</code>.</p>
					<?php else : ?>
						<?php echo urzone_pve_form_open( 'create_vm_iso', $node, $nonce, $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<div class="uzp-form-grid">
								<?php echo urzone_pve_admin_fields( $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<label>VM Name <input type="text" name="name" pattern="[A-Za-z0-9][A-Za-z0-9.\-]*" maxlength="63" required></label>
								<label>Installation ISO
									<select name="iso" required>
										<option value="">Select ISO image</option>
										<?php foreach ( $iso_images as $iso ) : ?>
											<?php $volid = (string) ( $iso['volid'] ?? '' ); ?>
											<?php if ( strpos( $volid, URZONE_PROXMOX_ISO_STORAGE . ':iso/' ) === 0 ) : ?>
												<option value="<?php echo esc_attr( $volid ); ?>"><?php echo esc_html( basename( $volid ) ); ?></option>
											<?php endif; ?>
										<?php endforeach; ?>
									</select>
								</label>
								<label>Disk Size (GB) <input type="number" name="disk_gb" min="4" max="<?php echo esc_attr( $caps['disk'] ); ?>" value="<?php echo esc_attr( min( 32, $caps['disk'] ) ); ?>" required></label>
								<label>CPU Cores <input type="number" name="cores" min="1" max="<?php echo esc_attr( $caps['cores'] ); ?>" value="<?php echo esc_attr( min( 2, $caps['cores'] ) ); ?>" required></label>
								<label>Memory (MB) <input type="number" name="memory" min="512" max="<?php echo esc_attr( $caps['memory'] ); ?>" value="<?php echo esc_attr( min( 2048, $caps['memory'] ) ); ?>" required></label>
								<label>Description <textarea name="description" placeholder="Optional notes"></textarea></label>
							</div>
							<?php echo urzone_pve_start_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<?php echo urzone_pve_vm_nesting_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<p><button type="submit" class="uzp-submit">Create My VM from ISO</button></p>
						</form>
					<?php endif; ?>
				</div>

				<div id="<?php echo esc_attr( $uid ); ?>-create-vm-empty" class="uzp-create-panel">
					<p class="uzp-mini">Creates a QEMU/KVM VM with a blank virtual disk. Attach an ISO or import an image before using it.</p>
					<?php echo urzone_pve_form_open( 'create_vm_empty', $node, $nonce, $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<div class="uzp-form-grid">
							<?php echo urzone_pve_admin_fields( $plan ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<label>VM Name <input type="text" name="name" pattern="[A-Za-z0-9][A-Za-z0-9.\-]*" maxlength="63" required></label>
							<label>Disk Size (GB) <input type="number" name="disk_gb" min="4" max="<?php echo esc_attr( $caps['disk'] ); ?>" value="<?php echo esc_attr( min( 32, $caps['disk'] ) ); ?>" required></label>
							<label>CPU Cores <input type="number" name="cores" min="1" max="<?php echo esc_attr( $caps['cores'] ); ?>" value="<?php echo esc_attr( min( 2, $caps['cores'] ) ); ?>" required></label>
							<label>Memory (MB) <input type="number" name="memory" min="512" max="<?php echo esc_attr( $caps['memory'] ); ?>" value="<?php echo esc_attr( min( 2048, $caps['memory'] ) ); ?>" required></label>
							<label>Description <textarea name="description" placeholder="Optional notes"></textarea></label>
						</div>
						<?php echo urzone_pve_start_checkbox( false ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php echo urzone_pve_vm_nesting_checkbox(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<p><button type="submit" class="uzp-submit">Create My Virtual Machine</button></p>
					</form>
				</div>

				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
	if ( $print_js ) {
		echo urzone_pve_js(); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	return ob_get_clean();
}

/**
 * Diagnostics: open any front-end page with ?uzpve_status=1 and view the page
 * source. If this comment is present, the core plugin is loaded on that site.
 */
function urzone_pve_status_comment() {
	if ( isset( $_GET['uzpve_status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo "\n<!-- urZONE PVE Core 2.8.1 loaded; shell " . ( urzone_pve_terminal_configured() ? 'configured' : 'not configured' ) . " -->\n";
	}
}

add_action( 'wp_footer', 'urzone_pve_status_comment' );

/*
|--------------------------------------------------------------------------
| Plan limits (free edition)
|--------------------------------------------------------------------------
|
| The free edition has no admin page for choosing how many PVE panels each plan
| gets, so the built-in limits below are always used. Other code can still
| override the final number with the 'urzone_pve_plan_limit' filter.
|
*/

/** Built-in panels per plan. */
function urzone_pve_plan_limit_defaults() {
	return array(
		'starter'  => 1,
		'business' => 5,
		'pro'      => 10,
		'agency'   => 20,
	);
}

/** Panels per plan (always the built-in limits in the free edition). */
function urzone_pve_plan_limits() {
	return urzone_pve_plan_limit_defaults();
}

/*
|--------------------------------------------------------------------------
| Demo cleanup schedule
|--------------------------------------------------------------------------
|
| Runs every minute on the MAIN site only (the demo lives on the front page).
| WP-Cron fires on page loads; for exact timing add a real cron job, e.g.
|   * * * * * curl -s https://urzone.org/wp-cron.php?doing_wp_cron >/dev/null 2>&1
|
*/

add_filter(
	'cron_schedules',
	static function ( $schedules ) {
		$schedules['uzpve_minute'] = array(
			'interval' => 60,
			'display'  => 'Every minute (urZONE PVE)',
		);

		return $schedules;
	}
);

add_action( 'urzone_pve_demo_cleanup_event', 'urzone_pve_demo_cleanup' );

add_action(
	'init',
	static function () {
		if ( is_main_site() && ! wp_next_scheduled( 'urzone_pve_demo_cleanup_event' ) ) {
			wp_schedule_event( time() + 30, 'uzpve_minute', 'urzone_pve_demo_cleanup_event' );
		}
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'urzone_pve_demo_cleanup_event' );
	}
);
