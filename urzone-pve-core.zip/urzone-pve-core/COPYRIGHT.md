# urZONE PVE: Copyright and Licensing

Copyright © 2026 Richard Charles Simmons, also known as Osiris Simmons and Osiris83.

## License

urZONE PVE Core (free edition) is free software. It is released under the GNU General Public License, version 2 or (at your option) any later version (GPL-2.0-or-later). The full text is in the `LICENSE` file.

You may use, study, change and share it under the terms of that license. If you share a copy, keep this copyright notice and the license with it.

## What the license does not cover

- The names **urZONE**, **urZONE PVE**, **Osiris Simmons** and **Osiris83**, and the urZONE logos and branding, are not licensed under the GPL. Please do not use them in a way that suggests your changed version is the official one.
- Other urZONE products, documentation and the content of urzone.org are not part of this repository. They are licensed separately.

## Third-party software

This work does not claim ownership of WordPress, Proxmox VE, xterm.js, Linux distributions, third-party libraries, open-source components or trademarks. They stay under their own licenses and belong to their owners.

## Contact

For permissions, copyright questions or reports of misuse, visit https://urzone.org
